const FELIPENOR_CHANNEL = 'felipenor';
const FELIPENOR_URL = `https://www.twitch.tv/${FELIPENOR_CHANNEL}`;
const FELIPENOR_VIDEO = 'https://www.twitch.tv/videos/2367175351';

const PARTNER_CHANNELS = [
  'WaferKon',
  'kirito_nautilus',
  'cat1hh',
  'baluartetm',
  'kiolhawuz',
  'alphaieslis',
  'rafael_1225',
  'b3lialtv',
  'ruffusthewolfu',
  'SplokBr',
  'Titan_BR_Play',
  'TobitoKaabe',
  'nagi_edits1',
  'Extreme_SL',
  'GaboAkk',
  'rarutosusto'
];

const CHECK_INTERVAL = 1;
const AUTO_RELOAD_ALARM = 'refreshTrackedLiveTabs';
const DEFAULT_AUTO_RELOAD_MINUTES = 5;
const MIN_AUTO_RELOAD_MINUTES = 1;
const MAX_AUTO_RELOAD_MINUTES = 720;
const LIVE_CHECK_TIMEOUT_MS = 8000;
const BLACKLIST_NOTICE_COOLDOWN_MS = 5000;
const TWITCH_AUTH_REDIRECT_URI = 'https://inkznmmvqmsorvblzvuu.supabase.co/auth/v1/callback';
const TWITCH_AUTH_SCOPES = ['user:read:email'];
const TWITCH_CLIENT_ID = 'jrxzvlwehkrk62trvocoik8juogwkv';
const TWITCH_HELIX_STREAMS_URL = 'https://api.twitch.tv/helix/streams';
const TWITCH_VALIDATE_URL = 'https://id.twitch.tv/oauth2/validate';
const TWITCH_AUTH_VALIDATE_INTERVAL_MS = 60 * 60 * 1000;
const TWITCH_HELIX_BATCH_SIZE = 100;
const AUTO_RELOAD_EARLY_TOLERANCE_MS = 5000;
const RAID_PROMPT_CLOSE_DELAY_MS = 30000;
const RAID_PROMPT_WINDOW_MS = 120000;
const LIVE_ENDED_CLOSE_MODE_ALL = 'all';
const LIVE_ENDED_CLOSE_MODE_SELECTED = 'selected';

const lurkTabs = new Map();
const liveEndedTabs = new Map();
const raidSourceChannels = new Map();
const recentBlacklistNoticeAt = new Map();
let runChecksInProgress = false;
let runChecksQueued = false;

const PARTNER_CHANNELS_NORMALIZED = [...new Set(PARTNER_CHANNELS.map((channel) => normalizeChannelName(channel)))];

function normalizeChannelName(channel) {
  return (channel || '').toLowerCase();
}

function normalizeChannelList(channels) {
  return [...new Set((channels || []).map(normalizeChannelName).filter(Boolean))];
}

function filterBlacklistedChannels(channels) {
  return normalizeChannelList(channels);
}

function normalizeAutoReloadMinutes(value) {
  const parsed = Number.parseInt(value, 10);
  if (!Number.isFinite(parsed)) return DEFAULT_AUTO_RELOAD_MINUTES;
  return Math.min(Math.max(parsed, MIN_AUTO_RELOAD_MINUTES), MAX_AUTO_RELOAD_MINUTES);
}

function normalizeLiveEndedCloseMode(value) {
  return value === LIVE_ENDED_CLOSE_MODE_SELECTED ? LIVE_ENDED_CLOSE_MODE_SELECTED : LIVE_ENDED_CLOSE_MODE_ALL;
}

function buildLiveEndedCloseConfig(settings = {}) {
  return {
    enabled: settings.closeEndedLiveTabsEnabled === true,
    mode: normalizeLiveEndedCloseMode(settings.closeEndedLiveTabsMode),
    channels: new Set(normalizeChannelList(settings.closeEndedLiveTabChannels || []))
  };
}

function shouldCloseLiveEndedTab(channelName, config = null) {
  const settings = config || buildLiveEndedCloseConfig();
  if (!settings.enabled) return false;
  if (settings.mode === LIVE_ENDED_CLOSE_MODE_ALL) return true;
  return settings.channels.has(normalizeChannelName(channelName));
}

function clearLiveEndedTabTimers(info = null) {
  if (!info) return;
  if (info.timerId) clearTimeout(info.timerId);
  if (info.cleanupTimerId) clearTimeout(info.cleanupTimerId);
}

function removeLiveEndedTabState(tabId) {
  const info = liveEndedTabs.get(tabId);
  clearLiveEndedTabTimers(info);
  liveEndedTabs.delete(tabId);
}

function cleanupExpiredLiveEndedTabs() {
  const now = Date.now();
  for (const [tabId, info] of liveEndedTabs.entries()) {
    if (!info?.expiresAt) continue;
    if (info.timerId) continue;
    if (!info.autoClose) continue;
    if (info.expiresAt > now) continue;
    liveEndedTabs.delete(tabId);
  }
}

function markRaidSourceChannel(channelName) {
  const normalizedChannel = normalizeChannelName(channelName);
  if (!normalizedChannel) return;
  raidSourceChannels.set(normalizedChannel, Date.now());
}

function clearRaidSourceChannel(channelName) {
  const normalizedChannel = normalizeChannelName(channelName);
  if (!normalizedChannel) return;
  raidSourceChannels.delete(normalizedChannel);
}

function clearRaidSourceChannelIfUnused(channelName) {
  const normalizedChannel = normalizeChannelName(channelName);
  if (!normalizedChannel) return;

  for (const channel of lurkTabs.values()) {
    if (normalizeChannelName(channel) === normalizedChannel) {
      return;
    }
  }

  raidSourceChannels.delete(normalizedChannel);
}

function scheduleLiveEndedTabState(tabId, info, config = null) {
  if (!info) return;

  const now = Date.now();
  const nextConfig = config || buildLiveEndedCloseConfig();
  const ts = Number(info.ts) || now;
  const closeAt = Number(info.closeAt) || (ts + RAID_PROMPT_CLOSE_DELAY_MS);
  const expiresAt = Number(info.expiresAt) || (ts + RAID_PROMPT_WINDOW_MS);
  const shouldAutoClose = info.raidPromptActive ? false : shouldCloseLiveEndedTab(info.channel, nextConfig);

  clearLiveEndedTabTimers(info);

  const nextInfo = {
    ...info,
    ts,
    closeAt,
    expiresAt,
    autoClose: shouldAutoClose,
    raidPromptActive: !!info.raidPromptActive,
    timerId: null,
    cleanupTimerId: null
  };

  if (shouldAutoClose) {
    nextInfo.timerId = setTimeout(() => {
      closeLiveEndedTab(tabId).catch(() => {});
    }, Math.max(0, closeAt - now));
  }

  liveEndedTabs.set(tabId, nextInfo);
}

async function applyLiveEndedClosePolicy() {
  const settings = await chrome.storage.local.get([
    'closeEndedLiveTabsEnabled',
    'closeEndedLiveTabsMode',
    'closeEndedLiveTabChannels'
  ]);
  const config = buildLiveEndedCloseConfig(settings);

  for (const [tabId, info] of [...liveEndedTabs.entries()]) {
    scheduleLiveEndedTabState(tabId, info, config);
  }

  cleanupExpiredLiveEndedTabs();
}

async function closeLiveEndedTab(tabId) {
  const info = liveEndedTabs.get(tabId);
  if (!info) return;

  clearLiveEndedTabTimers(info);

  const channel = normalizeChannelName(info.channel || lurkTabs.get(tabId) || '');
  try {
    if (channel === FELIPENOR_CHANNEL) {
      const mutedPref = await getMutePref(FELIPENOR_CHANNEL);
      const newTab = await chrome.tabs.create({ url: FELIPENOR_VIDEO, active: false });
      if (newTab?.id) {
        await chrome.tabs.update(newTab.id, { muted: mutedPref });
      }
    }

    await chrome.tabs.remove(tabId);
  } catch {}

  lurkTabs.delete(tabId);
  liveEndedTabs.delete(tabId);
}

function chunkArray(values, size) {
  const chunks = [];
  for (let index = 0; index < values.length; index += size) {
    chunks.push(values.slice(index, index + size));
  }
  return chunks;
}

async function getMutePref(channel) {
  const res = await chrome.storage.local.get(['channelMutePrefs']);
  const prefs = res.channelMutePrefs || {};
  return prefs[normalizeChannelName(channel)] !== false;
}

async function persistMutePrefs(nextPrefs) {
  await chrome.storage.local.set({ channelMutePrefs: nextPrefs });
}

function delay(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function getChannelFromTwitchUrl(rawUrl) {
  try {
    const url = new URL(rawUrl);
    if (!url.hostname.endsWith('twitch.tv')) return null;

    const parts = url.pathname.split('/').filter(Boolean);
    const first = parts[0];
    if (!first || first === 'videos') return null;

    return first.toLowerCase();
  } catch {
    return null;
  }
}

function isRootChannelUrl(rawUrl, channelName) {
  try {
    const url = new URL(rawUrl);
    if (!url.hostname.endsWith('twitch.tv')) return false;

    const parts = url.pathname.split('/').filter(Boolean);
    return parts.length === 1 && normalizeChannelName(parts[0]) === normalizeChannelName(channelName);
  } catch {
    return false;
  }
}

async function fetchWithTimeout(resource, options = {}, timeoutMs = LIVE_CHECK_TIMEOUT_MS) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);

  try {
    return await fetch(resource, { ...options, signal: controller.signal });
  } finally {
    clearTimeout(timer);
  }
}

function parseTwitchTokenResponse(redirectUrl) {
  const url = new URL(redirectUrl);
  const fragment = new URLSearchParams((url.hash || '').replace(/^#/, ''));
  const query = new URLSearchParams(url.search || '');
  const params = fragment.size > 0 ? fragment : query;

  return {
    accessToken: params.get('access_token') || '',
    expiresIn: Number.parseInt(params.get('expires_in') || '0', 10) || 0,
    state: params.get('state') || '',
    scope: (params.get('scope') || '').split(/[,\s]+/).filter(Boolean),
    error: params.get('error') || '',
    errorDescription: params.get('error_description') || ''
  };
}

function isTwitchAuthError(error) {
  return error?.name === 'TwitchAuthError' || error?.status === 401 || error?.status === 403;
}

function getTwitchRedirectResult(candidateUrl, redirectUri, expectedState = '') {
  if (!candidateUrl) {
    return {
      url: '',
      matchesRedirect: false,
      sameState: false,
      hasFinalResult: false,
      accessToken: '',
      error: '',
      errorDescription: '',
      isTwitchHost: false
    };
  }

  try {
    const url = new URL(candidateUrl);
    const parsed = parseTwitchTokenResponse(candidateUrl);
    const matchesRedirect = candidateUrl.startsWith(redirectUri);
    const sameState = !expectedState || !parsed.state || parsed.state === expectedState;
    const isTwitchHost = url.hostname === 'id.twitch.tv' || url.hostname.endsWith('.twitch.tv');

    return {
      url: candidateUrl,
      matchesRedirect,
      sameState,
      hasFinalResult: !!parsed.accessToken || !!parsed.error,
      accessToken: parsed.accessToken,
      error: parsed.error,
      errorDescription: parsed.errorDescription,
      isTwitchHost
    };
  } catch {
    return {
      url: candidateUrl,
      matchesRedirect: false,
      sameState: false,
      hasFinalResult: false,
      accessToken: '',
      error: '',
      errorDescription: '',
      isTwitchHost: false
    };
  }
}

async function getTabUrl(tabId) {
  try {
    const tab = await chrome.tabs.get(tabId);
    return tab?.url || '';
  } catch {
    return '';
  }
}

async function waitForTabAuthResult(tabId, redirectUri, expectedState = '', attempts = 40, intervalMs = 250) {
  for (let attempt = 0; attempt < attempts; attempt += 1) {
    const currentUrl = await getTabUrl(tabId);
    const result = getTwitchRedirectResult(currentUrl, redirectUri, expectedState);

    if (result.accessToken && result.sameState) {
      return result.url;
    }

    if (result.matchesRedirect && result.sameState && result.hasFinalResult) {
      return result.url;
    }

    await delay(intervalMs);
  }

  return '';
}

function waitForTabRedirect(tabId, redirectUri, expectedState = '', timeoutMs = 120000) {
  return new Promise((resolve, reject) => {
    let settled = false;
    let isChecking = false;

    const cleanup = () => {
      if (settled) return;
      settled = true;
      clearTimeout(timerId);
      chrome.tabs.onUpdated.removeListener(handleUpdated);
      chrome.tabs.onRemoved.removeListener(handleRemoved);
    };

    const fail = (message) => {
      const error = new Error(message);
      error.name = 'TwitchAuthError';
      cleanup();
      chrome.tabs.remove(tabId).catch(() => {});
      reject(error);
    };

    const maybeResolve = (candidateUrl = '') => {
      if (settled || isChecking) return;
      isChecking = true;

      Promise.resolve()
        .then(async () => {
          const urlsToInspect = [];
          if (candidateUrl) urlsToInspect.push(candidateUrl);

          const liveTabUrl = await getTabUrl(tabId);
          if (liveTabUrl && liveTabUrl !== candidateUrl) {
            urlsToInspect.push(liveTabUrl);
          }

          for (const url of urlsToInspect) {
            const result = getTwitchRedirectResult(url, redirectUri, expectedState);

            if (result.accessToken && result.sameState) {
              cleanup();
              resolve(result.url);
              return;
            }

            if (result.error && result.sameState && (result.matchesRedirect || result.isTwitchHost)) {
              fail(`Falha na autorizacao da Twitch: ${result.errorDescription || result.error}`);
              return;
            }

            if (result.matchesRedirect && result.sameState && result.hasFinalResult) {
              cleanup();
              resolve(result.url);
              return;
            }

            if (result.matchesRedirect && result.sameState) {
              const finalUrl = await waitForTabAuthResult(tabId, redirectUri, expectedState);
              if (finalUrl) {
                cleanup();
                resolve(finalUrl);
                return;
              }

              fail('Nao foi possivel concluir a autorizacao da Twitch.');
              return;
            }
          }
        })
        .catch(() => {})
        .finally(() => {
          isChecking = false;
        });
    };

    const handleUpdated = (updatedTabId, changeInfo, tab) => {
      if (updatedTabId !== tabId) return;

      const currentUrl = changeInfo.url || tab?.url || '';
      if (!currentUrl) return;
      maybeResolve(currentUrl);
    };

    const handleRemoved = (removedTabId) => {
      if (removedTabId !== tabId) return;
      fail('A autorização da Twitch foi cancelada.');
    };

    const timerId = setTimeout(() => {
      fail('Tempo esgotado ao aguardar a autorização da Twitch.');
    }, timeoutMs);

    chrome.tabs.onUpdated.addListener(handleUpdated);
    chrome.tabs.onRemoved.addListener(handleRemoved);
    maybeResolve();
  });
}

async function clearTwitchAuthSession() {
  const keys = [
    'twitchClientId',
    'twitchAccessToken',
    'twitchTokenExpiresAt',
    'twitchAuthLastValidatedAt',
    'twitchAuthLogin',
    'twitchAuthUserId',
    'twitchAuthScopes'
  ];

  await chrome.storage.local.remove(keys);
}

async function validateTwitchToken(clientId, accessToken) {
  const response = await fetchWithTimeout(TWITCH_VALIDATE_URL, {
    method: 'GET',
    headers: {
      'Client-ID': clientId,
      Authorization: `Bearer ${accessToken}`
    },
    cache: 'no-store'
  });

  if (!response.ok) {
    const error = new Error(`Twitch validate HTTP ${response.status}`);
    error.status = response.status;
    error.name = 'TwitchAuthError';
    throw error;
  }

  return response.json();
}

async function getStoredTwitchAuth() {
  const res = await chrome.storage.local.get([
    'twitchClientId',
    'twitchAccessToken',
    'twitchTokenExpiresAt',
    'twitchAuthLastValidatedAt',
    'twitchAuthLogin',
    'twitchAuthUserId',
    'twitchAuthScopes'
  ]);

  const clientId = (res.twitchClientId || TWITCH_CLIENT_ID).trim();
  const accessToken = (res.twitchAccessToken || '').trim();
  const expiresAt = Number(res.twitchTokenExpiresAt) || 0;
  const lastValidatedAt = Number(res.twitchAuthLastValidatedAt) || 0;

  if (!clientId || !accessToken) {
    return null;
  }

  if (expiresAt && expiresAt <= Date.now()) {
    await clearTwitchAuthSession();
    return null;
  }

  return {
    clientId,
    accessToken,
    expiresAt,
    lastValidatedAt,
    login: (res.twitchAuthLogin || '').trim(),
    userId: (res.twitchAuthUserId || '').trim(),
    scopes: Array.isArray(res.twitchAuthScopes) ? res.twitchAuthScopes : []
  };
}

async function getValidatedTwitchAuth() {
  const auth = await getStoredTwitchAuth();
  if (!auth) return null;

  const isFresh = auth.lastValidatedAt && (Date.now() - auth.lastValidatedAt) < TWITCH_AUTH_VALIDATE_INTERVAL_MS;
  if (isFresh) {
    return auth;
  }

  try {
    const validation = await validateTwitchToken(auth.clientId, auth.accessToken);
    const expiresIn = Number(validation?.expires_in) || 0;
    const nextAuth = {
      ...auth,
      lastValidatedAt: Date.now(),
      login: (validation?.login || auth.login || '').trim(),
      userId: (validation?.user_id || auth.userId || '').trim(),
      scopes: Array.isArray(validation?.scopes) ? validation.scopes : auth.scopes,
      expiresAt: expiresIn > 0 ? Date.now() + (expiresIn * 1000) : auth.expiresAt
    };

    await chrome.storage.local.set({
      twitchTokenExpiresAt: nextAuth.expiresAt || 0,
      twitchAuthLastValidatedAt: nextAuth.lastValidatedAt,
      twitchAuthLogin: nextAuth.login || '',
      twitchAuthUserId: nextAuth.userId || '',
      twitchAuthScopes: nextAuth.scopes || []
    });

    return nextAuth;
  } catch (error) {
    if (isTwitchAuthError(error)) {
      await clearTwitchAuthSession();
      return null;
    }

    console.warn('Falha ao validar a sessão da Twitch, mantendo o token salvo para tentativa futura:', error);
    return auth;
  }
}

async function connectTwitchAuth(clientId = TWITCH_CLIENT_ID) {
  const normalizedClientId = (clientId || TWITCH_CLIENT_ID).trim();
  if (!normalizedClientId) {
    const error = new Error('Client ID da Twitch não informado.');
    error.name = 'TwitchAuthError';
    throw error;
  }

  const authUrl = new URL('https://id.twitch.tv/oauth2/authorize');
  authUrl.searchParams.set('client_id', normalizedClientId);
  authUrl.searchParams.set('redirect_uri', TWITCH_AUTH_REDIRECT_URI);
  authUrl.searchParams.set('response_type', 'token');
  authUrl.searchParams.set('force_verify', 'true');
  authUrl.searchParams.set('scope', TWITCH_AUTH_SCOPES.join(' '));
  const authState = globalThis.crypto?.randomUUID?.() || `${Date.now()}-${Math.random().toString(36).slice(2)}`;
  authUrl.searchParams.set('state', authState);

  const authTab = await chrome.tabs.create({
    url: authUrl.toString(),
    active: true
  });

  if (!authTab?.id) {
    const error = new Error('Nao foi possivel abrir a autorizacao da Twitch.');
    error.name = 'TwitchAuthError';
    throw error;
  }

  let redirectedTo = '';
  try {
    redirectedTo = await waitForTabRedirect(authTab.id, TWITCH_AUTH_REDIRECT_URI, authState);
  } catch (error) {
    const authError = new Error(error?.message || 'A autorizacao da Twitch foi cancelada.');
    authError.name = 'TwitchAuthError';
    throw authError;
  } finally {
    try {
      await chrome.tabs.remove(authTab.id);
    } catch {}
  }

  if (!redirectedTo) {
    const error = new Error('Nao foi possivel concluir a autorizacao da Twitch.');
    error.name = 'TwitchAuthError';
    throw error;
  }

  const tokenData = parseTwitchTokenResponse(redirectedTo);
  if (tokenData.error) {
    const errorMessage = tokenData.errorDescription || tokenData.error;
    const error = new Error(`Falha na autorizacao da Twitch: ${errorMessage}`);
    error.name = 'TwitchAuthError';
    throw error;
  }

  if (tokenData.state && tokenData.state !== authState) {
    const error = new Error('A resposta de autorizacao da Twitch nao corresponde a esta tentativa.');
    error.name = 'TwitchAuthError';
    throw error;
  }

  if (!tokenData.accessToken) {
    const error = new Error('Não foi possível ler o token da Twitch.');
    error.name = 'TwitchAuthError';
    throw error;
  }

  const now = Date.now();
  await chrome.storage.local.set({
    twitchClientId: normalizedClientId,
    twitchAccessToken: tokenData.accessToken,
    twitchTokenExpiresAt: tokenData.expiresIn > 0 ? now + (tokenData.expiresIn * 1000) : 0,
    twitchAuthLastValidatedAt: 0,
    twitchAuthLogin: '',
    twitchAuthUserId: '',
    twitchAuthScopes: tokenData.scope || []
  });

  try {
    const validation = await validateTwitchToken(normalizedClientId, tokenData.accessToken);
    const expiresIn = Number(validation?.expires_in) || tokenData.expiresIn || 0;
    const nextAuth = {
      twitchTokenExpiresAt: expiresIn > 0 ? Date.now() + (expiresIn * 1000) : 0,
      twitchAuthLastValidatedAt: Date.now(),
      twitchAuthLogin: (validation?.login || '').trim(),
      twitchAuthUserId: (validation?.user_id || '').trim(),
      twitchAuthScopes: Array.isArray(validation?.scopes) ? validation.scopes : tokenData.scope || []
    };

    await chrome.storage.local.set(nextAuth);

    return {
      clientId: normalizedClientId,
      login: nextAuth.twitchAuthLogin || '',
      expiresAt: nextAuth.twitchTokenExpiresAt || 0,
      validated: true
    };
  } catch (error) {
    if (isTwitchAuthError(error)) {
      await clearTwitchAuthSession();
      const authError = new Error('O token da Twitch foi recusado. Tente autorizar novamente.');
      authError.name = 'TwitchAuthError';
      throw authError;
    }

    return {
      clientId: normalizedClientId,
      login: '',
      expiresAt: now + ((tokenData.expiresIn || 0) * 1000),
      validated: false,
      warning: 'Token salvo, mas a validação falhou agora. A extensão vai tentar novamente depois.'
    };
  }
}

async function disconnectTwitchAuth() {
  await clearTwitchAuthSession();
}

async function fetchOfficialTwitchLiveSet(channelNames) {
  const auth = await getValidatedTwitchAuth();
  if (!auth?.clientId || !auth?.accessToken) return null;

  const normalizedChannels = normalizeChannelList(channelNames);
  if (normalizedChannels.length === 0) return new Set();

  const liveSet = new Set();

  try {
    for (const batch of chunkArray(normalizedChannels, TWITCH_HELIX_BATCH_SIZE)) {
      const url = new URL(TWITCH_HELIX_STREAMS_URL);
      batch.forEach((channel) => url.searchParams.append('user_login', channel));

      const response = await fetchWithTimeout(url.toString(), {
        method: 'GET',
        headers: {
          'Client-ID': auth.clientId,
          Authorization: `Bearer ${auth.accessToken}`,
          Accept: 'application/json'
        },
        cache: 'no-store'
      });

      if (response.status === 401 || response.status === 403) {
        const error = new Error(`Twitch Helix rejeitou a sessão com status ${response.status}`);
        error.name = 'TwitchAuthError';
        error.status = response.status;
        throw error;
      }

      if (!response.ok) {
        throw new Error(`Twitch Helix HTTP ${response.status}`);
      }

      const data = await response.json();
      for (const stream of data?.data || []) {
        if (stream?.user_login) {
          liveSet.add(normalizeChannelName(stream.user_login));
        }
      }
    }

    return liveSet;
  } catch (error) {
    if (isTwitchAuthError(error)) {
      await clearTwitchAuthSession();
      return null;
    }

    console.warn('Falha ao consultar a API oficial da Twitch, usando o fallback local:', error);
    return null;
  }
}

async function resolveChannelLiveState(channelName, officialLiveSet = null) {
  const login = normalizeChannelName(channelName);
  if (officialLiveSet instanceof Set) {
    return officialLiveSet.has(login);
  }

  return isChannelLiveReliable(login, 2);
}

async function getManagedChannelSnapshot() {
  const result = await chrome.storage.local.get(['lurkChannels', 'channelBlacklist']);
  const userChannels = normalizeChannelList(result.lurkChannels || []);
  const managedSet = new Set([
    ...PARTNER_CHANNELS_NORMALIZED,
    ...userChannels,
    FELIPENOR_CHANNEL
  ]);
  const blacklistedChannels = filterBlacklistedChannels(result.channelBlacklist || []).filter((channel) => !managedSet.has(channel));
  const blockedSet = new Set(blacklistedChannels);

  const openableChannels = normalizeChannelList([
    ...managedSet
  ]).filter((channel) => !blockedSet.has(channel));

  return {
    userChannels,
    blacklistedChannels,
    blockedSet,
    managedSet,
    openableChannels,
    openableSet: new Set(openableChannels)
  };
}

async function purgeTrackedChannelState(channelName, { showNotice = false } = {}) {
  const normalizedChannel = normalizeChannelName(channelName);
  if (!normalizedChannel) return 0;

  const tabs = await chrome.tabs.query({ url: `*://*.twitch.tv/${normalizedChannel}*` });
  let removedCount = 0;
  let noticeWindowId = null;

  for (const tab of tabs) {
    if (getChannelFromTwitchUrl(tab.url) !== normalizedChannel) continue;

    try {
      if (noticeWindowId === null && Number.isInteger(tab.windowId)) {
        noticeWindowId = tab.windowId;
      }
      await chrome.tabs.remove(tab.id);
    } catch {}

    removedCount += 1;
    lurkTabs.delete(tab.id);
    removeLiveEndedTabState(tab.id);
  }

  if (showNotice && removedCount > 0) {
    await showBlacklistClosureNotice(normalizedChannel, noticeWindowId);
  }

  clearRaidSourceChannel(normalizedChannel);
  return removedCount;
}

function isTwitchTabUrl(tab) {
  const url = tab?.url || tab?.pendingUrl || '';
  return typeof url === 'string' && url.includes('twitch.tv');
}

async function resolveBlacklistNoticeTargetTab(windowId = null) {
  const pickTab = async (query) => {
    const tabs = await chrome.tabs.query(query);
    const twitchTabs = tabs.filter(isTwitchTabUrl);
    return twitchTabs.find((tab) => tab.active) || twitchTabs[0] || null;
  };

  if (Number.isInteger(windowId)) {
    const windowTab = await pickTab({ windowId });
    if (windowTab) return windowTab;
  }

  return await pickTab({});
}

async function injectBlacklistNoticeOverlay(tabId, channelName) {
  await chrome.scripting.executeScript({
    target: { tabId },
    func: (rawChannel) => {
      const OVERLAY_ID = 'shadowlurk-blacklist-overlay';
      const normalizedChannel = (rawChannel || '').trim() || 'desconhecido';
      const existing = document.getElementById(OVERLAY_ID);

      if (existing) {
        const channelLabel = existing.querySelector('.shadowlurk-blacklist-channel');
        const okButton = existing.querySelector('.shadowlurk-blacklist-ok');
        if (channelLabel) channelLabel.textContent = normalizedChannel;
        if (okButton) okButton.focus();
        return;
      }

      const style = document.createElement('style');
      style.textContent = `
        #${OVERLAY_ID} {
          position: fixed;
          inset: 0;
          display: grid;
          place-items: center;
          padding: 24px;
          background: rgba(7, 7, 12, 0.84);
          backdrop-filter: blur(6px);
          z-index: 2147483647;
        }
        #${OVERLAY_ID} .shadowlurk-blacklist-card {
          width: min(560px, calc(100vw - 32px));
          max-height: calc(100vh - 32px);
          overflow: auto;
          background: linear-gradient(180deg, #1c1c22 0%, #141419 100%);
          border: 1px solid rgba(255, 255, 255, 0.08);
          border-radius: 20px;
          box-shadow: 0 24px 70px rgba(0, 0, 0, 0.55);
          color: #efeff1;
          padding: 26px 28px;
          font-family: 'Segoe UI', sans-serif;
        }
        #${OVERLAY_ID} .shadowlurk-blacklist-eyebrow {
          margin: 0 0 10px;
          color: #00db84;
          text-transform: uppercase;
          letter-spacing: 0.18em;
          font-weight: 800;
          font-size: 11px;
        }
        #${OVERLAY_ID} h1 {
          margin: 0;
          font-size: 24px;
          line-height: 1.2;
          color: #ffffff;
        }
        #${OVERLAY_ID} .shadowlurk-blacklist-message {
          margin: 14px 0 0;
          font-size: 15px;
          line-height: 1.7;
          color: #c8c8d0;
        }
        #${OVERLAY_ID} .shadowlurk-blacklist-channel {
          color: #ffffff;
          font-weight: 700;
          word-break: break-word;
        }
        #${OVERLAY_ID} .shadowlurk-blacklist-actions {
          display: flex;
          justify-content: flex-end;
          margin-top: 22px;
        }
        #${OVERLAY_ID} .shadowlurk-blacklist-ok {
          min-width: 96px;
          padding: 12px 18px;
          border: none;
          border-radius: 12px;
          background: linear-gradient(135deg, #9146ff, #772ce8);
          color: white;
          font-weight: 800;
          cursor: pointer;
          box-shadow: 0 12px 24px rgba(145, 70, 255, 0.28);
        }
        #${OVERLAY_ID} .shadowlurk-blacklist-ok:hover {
          filter: brightness(1.05);
        }
        #${OVERLAY_ID} .shadowlurk-blacklist-ok:focus-visible {
          outline: 2px solid rgba(255, 255, 255, 0.92);
          outline-offset: 2px;
        }
      `;

      const overlay = document.createElement('div');
      overlay.id = OVERLAY_ID;
      overlay.innerHTML = `
        <div class="shadowlurk-blacklist-card" role="dialog" aria-modal="true" aria-labelledby="shadowlurk-blacklist-title">
          <p class="shadowlurk-blacklist-eyebrow">SHADOWLURK</p>
          <h1 id="shadowlurk-blacklist-title">Guia fechada por blacklist</h1>
          <p class="shadowlurk-blacklist-message">
            A guia do canal <strong class="shadowlurk-blacklist-channel"></strong> foi fechada porque esse canal está na blacklist.
            Clique em <strong>OK</strong> para fechar este aviso.
          </p>
          <div class="shadowlurk-blacklist-actions">
            <button type="button" class="shadowlurk-blacklist-ok">OK</button>
          </div>
        </div>
      `;

      const channelLabel = overlay.querySelector('.shadowlurk-blacklist-channel');
      const okButton = overlay.querySelector('.shadowlurk-blacklist-ok');
      if (channelLabel) channelLabel.textContent = normalizedChannel;

      const previousHtmlOverflow = document.documentElement.style.overflow;
      const previousBodyOverflow = document.body?.style?.overflow || '';

      const closeNotice = () => {
        overlay.remove();
        style.remove();
        document.documentElement.style.overflow = previousHtmlOverflow;
        if (document.body) {
          document.body.style.overflow = previousBodyOverflow;
        }
        document.removeEventListener('keydown', handleKeyDown, true);
      };

      const handleKeyDown = (event) => {
        if (event.key === 'Escape' || event.key === 'Enter') {
          event.preventDefault();
          closeNotice();
        }
      };

      overlay.addEventListener('click', (event) => {
        if (event.target === overlay) {
          closeNotice();
        }
      });

      okButton?.addEventListener('click', closeNotice);
      document.documentElement.style.overflow = 'hidden';
      if (document.body) {
        document.body.style.overflow = 'hidden';
      }
      (document.body || document.documentElement).appendChild(style);
      (document.body || document.documentElement).appendChild(overlay);
      document.addEventListener('keydown', handleKeyDown, true);
      okButton?.focus();
    },
    args: [channelName]
  });
}

async function injectRaidPromptOverlay(tabId, fromChannel, toChannel) {
  await chrome.scripting.executeScript({
    target: { tabId },
    func: (rawFromChannel, rawToChannel) => {
      const OVERLAY_ID = 'shadowlurk-raid-popup';
      const normalizedFrom = (rawFromChannel || '').trim() || 'desconhecido';
      const normalizedTo = (rawToChannel || '').trim() || 'desconhecido';
      const existing = document.getElementById(OVERLAY_ID);

      if (existing) {
        const fromLabel = existing.querySelector('.shadowlurk-raid-from');
        const toLabel = existing.querySelector('.shadowlurk-raid-to');
        const keepBtn = existing.querySelector('.shadowlurk-raid-close');
        if (fromLabel) fromLabel.textContent = normalizedFrom;
        if (toLabel) toLabel.textContent = normalizedTo;
        if (keepBtn) keepBtn.focus();
        return;
      }

      const style = document.createElement('style');
      style.textContent = `
        #${OVERLAY_ID} {
          position: fixed;
          bottom: 24px;
          left: 24px;
          width: min(420px, calc(100vw - 32px));
          background: linear-gradient(180deg, #1b1b20 0%, #141418 100%);
          border: 1px solid rgba(255, 255, 255, 0.08);
          box-shadow: 0 16px 40px rgba(0, 0, 0, 0.5);
          border-radius: 16px;
          color: #efeff1;
          z-index: 2147483647;
          padding: 16px;
          animation: fadeIn 0.2s ease-out;
          font-family: 'Segoe UI', sans-serif;
        }
        #${OVERLAY_ID} .shadowlurk-raid-header {
          display: flex;
          justify-content: space-between;
          align-items: flex-start;
          gap: 12px;
          margin-bottom: 10px;
        }
        #${OVERLAY_ID} h3 {
          margin: 0 0 8px;
          font-size: 16px;
          color: #9146FF;
        }
        #${OVERLAY_ID} p {
          margin: 0;
          font-size: 13px;
          color: #c8c8d0;
          line-height: 1.5;
        }
        #${OVERLAY_ID} .shadowlurk-raid-close {
          flex-shrink: 0;
          width: 30px;
          height: 30px;
          border: none;
          border-radius: 50%;
          background: rgba(255, 255, 255, 0.06);
          color: #efeff1;
          font-size: 22px;
          line-height: 1;
          cursor: pointer;
          padding: 0;
        }
        #${OVERLAY_ID} .shadowlurk-raid-close:hover {
          background: rgba(255, 255, 255, 0.12);
        }
        #${OVERLAY_ID} .shadowlurk-raid-actions {
          display: flex;
          gap: 8px;
          margin-top: 12px;
        }
        #${OVERLAY_ID} .shadowlurk-btn {
          flex: 1;
          padding: 10px 12px;
          border: none;
          border-radius: 10px;
          font-weight: 700;
          cursor: pointer;
        }
        #${OVERLAY_ID} .shadowlurk-btn.close-guide {
          background: #e91916;
          color: white;
        }
        #${OVERLAY_ID} .shadowlurk-btn.close-guide:hover {
          filter: brightness(1.05);
        }
      `;

      const popup = document.createElement('div');
      popup.id = OVERLAY_ID;
      popup.innerHTML = `
        <div class="shadowlurk-raid-header">
          <div>
            <h3>ShadowLurk: Raid detectada</h3>
            <p>
              O canal <strong class="shadowlurk-raid-from"></strong> encerrou a live e raidou
              <strong class="shadowlurk-raid-to"></strong>.
            </p>
          </div>
          <button type="button" class="shadowlurk-raid-close" aria-label="Fechar aviso">&times;</button>
        </div>
        <p>Clique no X para continuar assistindo. Se quiser encerrar esta guia, use o botÃ£o vermelho abaixo.</p>
        <div class="shadowlurk-raid-actions">
          <button type="button" class="shadowlurk-btn close-guide">Fechar guia</button>
        </div>
      `;

      const fromLabel = popup.querySelector('.shadowlurk-raid-from');
      const toLabel = popup.querySelector('.shadowlurk-raid-to');
      const dismissBtn = popup.querySelector('.shadowlurk-raid-close');
      const closeBtn = popup.querySelector('.close-guide');
      if (fromLabel) fromLabel.textContent = normalizedFrom;
      if (toLabel) toLabel.textContent = normalizedTo;

      const previousHtmlOverflow = document.documentElement.style.overflow;
      const previousBodyOverflow = document.body?.style?.overflow || '';

      const closePopup = () => {
        popup.remove();
        style.remove();
        document.documentElement.style.overflow = previousHtmlOverflow;
        if (document.body) {
          document.body.style.overflow = previousBodyOverflow;
        }
        document.removeEventListener('keydown', handleKeyDown, true);
      };

      const handleKeyDown = (event) => {
        if (event.key === 'Escape' || event.key === 'Enter') {
          event.preventDefault();
          closePopup();
        }
      };

      const sendAction = (action) => {
        try {
          chrome.runtime.sendMessage({
            type: 'RAID_PROMPT_ACTION',
            action,
            toChannel: normalizedTo
          });
        } catch {}
      };

      dismissBtn?.addEventListener('click', () => {
        sendAction('keep');
        closePopup();
      });

      closeBtn?.addEventListener('click', () => {
        sendAction('close');
        closePopup();
      });

      popup.addEventListener('click', (event) => {
        if (event.target === popup) {
          sendAction('keep');
          closePopup();
        }
      });

      document.documentElement.style.overflow = 'hidden';
      if (document.body) {
        document.body.style.overflow = 'hidden';
      }
      (document.body || document.documentElement).appendChild(style);
      (document.body || document.documentElement).appendChild(popup);
      document.addEventListener('keydown', handleKeyDown, true);
      dismissBtn?.focus();
    },
    args: [fromChannel, toChannel]
  });
}

async function showBlacklistClosureNotice(channelName, windowId = null) {
  const normalizedChannel = normalizeChannelName(channelName);
  if (!normalizedChannel) return;

  const now = Date.now();
  const lastShownAt = recentBlacklistNoticeAt.get(normalizedChannel) || 0;
  if ((now - lastShownAt) < BLACKLIST_NOTICE_COOLDOWN_MS) return;

  try {
    const targetTab = await resolveBlacklistNoticeTargetTab(windowId);
    if (!targetTab?.id) return;

    if (Number.isInteger(targetTab.windowId)) {
      try {
        await chrome.windows.update(targetTab.windowId, { focused: true });
      } catch {}
    }

    try {
      await chrome.tabs.update(targetTab.id, { active: true });
    } catch {}

    try {
      await chrome.tabs.sendMessage(targetTab.id, {
        type: 'SHOW_BLACKLIST_NOTICE',
        channel: normalizedChannel
      });
    } catch {
      await injectBlacklistNoticeOverlay(targetTab.id, normalizedChannel);
    }

    recentBlacklistNoticeAt.set(normalizedChannel, now);
  } catch (error) {
    console.warn('Falha ao mostrar aviso da blacklist:', error);
  }
}

async function enforceBlacklistTabs(snapshot = null) {
  const managed = snapshot || await getManagedChannelSnapshot();
  if (!managed.blockedSet || managed.blockedSet.size === 0) return 0;

  const tabs = await chrome.tabs.query({ url: '*://*.twitch.tv/*' });
  const channelsToPurge = new Set();

  for (const tab of tabs) {
    const channel = getChannelFromTwitchUrl(tab.url);
    if (!channel) continue;
    if (!managed.blockedSet.has(channel)) continue;
    if (managed.managedSet?.has(channel)) continue;
    channelsToPurge.add(channel);
  }

  await Promise.all([...channelsToPurge].map((channel) => purgeTrackedChannelState(channel, { showNotice: true })));
  return channelsToPurge.size;
}

async function closeTrackedTabs() {
  await chrome.alarms.clear(AUTO_RELOAD_ALARM);
  await chrome.storage.local.set({ autoReloadNextAt: null });

  for (const [, info] of liveEndedTabs.entries()) {
    clearLiveEndedTabTimers(info);
  }

  liveEndedTabs.clear();
  raidSourceChannels.clear();

  const toClose = [...lurkTabs.keys()];
  lurkTabs.clear();

  for (const tabId of toClose) {
    try {
      await chrome.tabs.remove(tabId);
    } catch {}
  }

  try {
    const vodTabs = await chrome.tabs.query({ url: '*://*.twitch.tv/videos/2367175351*' });
    for (const tab of vodTabs) {
      try {
        await chrome.tabs.remove(tab.id);
      } catch {}
    }
  } catch {}

  try {
    const felipTabs = await chrome.tabs.query({ url: '*://*.twitch.tv/felipenor*' });
    for (const tab of felipTabs) {
      try {
        await chrome.tabs.remove(tab.id);
      } catch {}
    }
  } catch {}

  try {
    const result = await chrome.storage.local.get(['lurkChannels']);
    const managedChannels = new Set([
      ...PARTNER_CHANNELS.map(normalizeChannelName),
      ...(result.lurkChannels || []).map(normalizeChannelName),
      FELIPENOR_CHANNEL
    ]);

    const twitchTabs = await chrome.tabs.query({ url: '*://*.twitch.tv/*' });
    for (const tab of twitchTabs) {
      const channel = getChannelFromTwitchUrl(tab.url);
      const isFelipenorVod = tab.url?.includes('/videos/2367175351');
      if ((channel && managedChannels.has(channel)) || isFelipenorVod) {
        try {
          await chrome.tabs.remove(tab.id);
        } catch {}
      }
    }
  } catch {}
}

function scheduleAlarms() {
  chrome.alarms.clear('checkStreams', () => {
    chrome.alarms.create('checkStreams', { periodInMinutes: CHECK_INTERVAL });
  });
}

async function scheduleAutoReloadAlarm({ nextAt = 0 } = {}) {
  const settings = await chrome.storage.local.get([
    'extensionEnabled',
    'autoReloadEnabled',
    'autoReloadMinutes',
    'autoReloadLastRunAt',
    'channelBlacklist'
  ]);
  await chrome.alarms.clear(AUTO_RELOAD_ALARM);

  if (settings.extensionEnabled === false || !settings.autoReloadEnabled) {
    await chrome.storage.local.set({
      autoReloadNextAt: null,
      autoReloadLastRunAt: null
    });
    return;
  }

  const intervalMinutes = normalizeAutoReloadMinutes(settings.autoReloadMinutes);
  const normalizedNextAt = Number(nextAt);
  const scheduledTime = normalizedNextAt > Date.now()
    ? normalizedNextAt
    : Date.now() + intervalMinutes * 60 * 1000;

  chrome.alarms.create(AUTO_RELOAD_ALARM, {
    when: scheduledTime,
    periodInMinutes: intervalMinutes
  });

  await chrome.storage.local.set({
    autoReloadNextAt: scheduledTime
  });
}

async function collectManagedLiveTabs(openableSet = null) {
  const snapshot = openableSet ? { openableSet } : await getManagedChannelSnapshot();
  const managedChannels = snapshot.openableSet || new Set();

  const tabs = await chrome.tabs.query({ url: '*://*.twitch.tv/*' });
  const tracked = new Map();

  for (const tab of tabs) {
    const channel = getChannelFromTwitchUrl(tab.url);
    if (!channel || !managedChannels.has(channel)) continue;
    if (!isRootChannelUrl(tab.url, channel)) continue;
    tracked.set(tab.id, channel);
  }

  for (const [tabId, channel] of lurkTabs.entries()) {
    const normalizedChannel = normalizeChannelName(channel);
    if (!managedChannels.has(normalizedChannel)) continue;
    tracked.set(tabId, normalizedChannel);
  }

  return [...tracked.entries()].map(([tabId, channel]) => ({ tabId, channel }));
}

async function reloadTrackedLiveTabs() {
  const settings = await chrome.storage.local.get(['extensionEnabled']);
  if (settings.extensionEnabled === false) return;

  await syncMutePrefsWithTabs();

  const { openableSet } = await getManagedChannelSnapshot();
  await purgeTrackedTabsNotInSet(openableSet);
  const entries = await collectManagedLiveTabs(openableSet);
  if (entries.length === 0) return 0;

  const { channelMutePrefs = {} } = await chrome.storage.local.get(['channelMutePrefs']);
  let reloadCount = 0;

  for (const { tabId, channel } of entries) {
    if (liveEndedTabs.has(tabId)) continue;

    try {
      const tab = await chrome.tabs.get(tabId);
      if (!tab?.id) {
        lurkTabs.delete(tabId);
        continue;
      }

      await chrome.tabs.reload(tabId, { bypassCache: true });
      await chrome.tabs.update(tabId, {
        active: false,
        pinned: true,
        muted: channelMutePrefs[normalizeChannelName(channel)] !== false
      });
      lurkTabs.set(tabId, normalizeChannelName(channel));
      reloadCount += 1;
    } catch {
      lurkTabs.delete(tabId);
      removeLiveEndedTabState(tabId);
    }
  }

  return reloadCount;
}

async function purgeTrackedTabsNotInSet(openableSet) {
  if (!(openableSet instanceof Set)) return 0;

  let removedCount = 0;
  for (const [tabId, channel] of [...lurkTabs.entries()]) {
    if (openableSet.has(normalizeChannelName(channel))) continue;

    try {
      await chrome.tabs.remove(tabId);
    } catch {}

    lurkTabs.delete(tabId);
    removeLiveEndedTabState(tabId);
    removedCount += 1;
  }

  return removedCount;
}

async function handleAutoReloadAlarm() {
  const settings = await chrome.storage.local.get([
    'extensionEnabled',
    'autoReloadEnabled',
    'autoReloadMinutes',
    'autoReloadLastRunAt',
    'autoReloadNextAt'
  ]);

  if (settings.extensionEnabled === false || !settings.autoReloadEnabled) {
    await scheduleAutoReloadAlarm();
    return;
  }

  const intervalMs = normalizeAutoReloadMinutes(settings.autoReloadMinutes) * 60 * 1000;
  const lastRunAt = Number(settings.autoReloadLastRunAt) || 0;
  const nextAt = Number(settings.autoReloadNextAt) || 0;
  const now = Date.now();
  const triggerAt = now;
  const earliestNextRun = lastRunAt + intervalMs;

  if (nextAt && now + AUTO_RELOAD_EARLY_TOLERANCE_MS < nextAt) {
    await chrome.storage.local.set({ autoReloadNextAt: nextAt });
    return;
  }

  if (lastRunAt && now + AUTO_RELOAD_EARLY_TOLERANCE_MS < earliestNextRun) {
    await chrome.storage.local.set({ autoReloadNextAt: earliestNextRun });
    return;
  }

  try {
    await reloadTrackedLiveTabs();
  } catch (error) {
    console.error('Erro ao recarregar as lives monitoradas:', error);
  } finally {
    await chrome.storage.local.set({
      autoReloadLastRunAt: triggerAt,
      autoReloadNextAt: triggerAt + intervalMs
    });
  }
}

async function initializeExtensionState({ runInitialChecks = true } = {}) {
  const settings = await chrome.storage.local.get([
    'extensionEnabled',
    'autoReloadEnabled',
    'autoReloadMinutes',
    'autoReloadLastRunAt',
    'closeEndedLiveTabsEnabled',
    'closeEndedLiveTabsMode',
    'closeEndedLiveTabChannels'
  ]);
  const nextSettings = {};

  if (typeof settings.extensionEnabled === 'undefined') {
    nextSettings.extensionEnabled = true;
  }

  if (typeof settings.autoReloadEnabled === 'undefined') {
    nextSettings.autoReloadEnabled = false;
  }

  if (typeof settings.autoReloadMinutes === 'undefined') {
    nextSettings.autoReloadMinutes = DEFAULT_AUTO_RELOAD_MINUTES;
  }

  if (typeof settings.autoReloadLastRunAt === 'undefined') {
    nextSettings.autoReloadLastRunAt = null;
  }

  if (typeof settings.closeEndedLiveTabsEnabled === 'undefined') {
    nextSettings.closeEndedLiveTabsEnabled = false;
  }

  if (typeof settings.closeEndedLiveTabsMode === 'undefined') {
    nextSettings.closeEndedLiveTabsMode = LIVE_ENDED_CLOSE_MODE_ALL;
  }

  if (typeof settings.closeEndedLiveTabChannels === 'undefined') {
    nextSettings.closeEndedLiveTabChannels = [];
  }

  if (typeof settings.channelBlacklist === 'undefined') {
    nextSettings.channelBlacklist = [];
  }

  if (Object.keys(nextSettings).length > 0) {
    await chrome.storage.local.set(nextSettings);
  }

  await enforceBlacklistTabs();
  await applyLiveEndedClosePolicy();

  scheduleAlarms();
  await scheduleAutoReloadAlarm();
  if (runInitialChecks) {
    runChecks();
  }
}

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === 'checkStreams') {
    runChecks();
    return;
  }

  if (alarm.name === AUTO_RELOAD_ALARM) {
    handleAutoReloadAlarm().catch((error) => {
      console.error('Falha no ciclo da recarga automática:', error);
    });
  }
});

chrome.runtime.onStartup.addListener(() => {
  initializeExtensionState().catch((error) => {
    console.error('Erro ao inicializar ao iniciar o navegador:', error);
  });
});

chrome.runtime.onInstalled.addListener(() => {
  initializeExtensionState().catch((error) => {
    console.error('Erro ao inicializar após instalação/atualização:', error);
  });
});

chrome.tabs.onRemoved.addListener((tabId) => {
  const channel = lurkTabs.get(tabId);
  lurkTabs.delete(tabId);
  removeLiveEndedTabState(tabId);
  clearRaidSourceChannelIfUnused(channel);
});

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if ((changeInfo.url || changeInfo.status === 'complete') && tab?.url?.includes('twitch.tv')) {
    enforceBlacklistTabs().catch(() => {});
  }

  if (!changeInfo.mutedInfo) return;
  if (!lurkTabs.has(tabId)) return;
  syncMutePrefsWithTabs().catch(() => {});
});

chrome.storage.onChanged.addListener((changes, areaName) => {
  if (areaName !== 'local') return;

  if (changes.extensionEnabled) {
    if (changes.extensionEnabled.newValue === true) {
      applyLiveEndedClosePolicy().catch(() => {});
      runChecks();
      scheduleAutoReloadAlarm().catch(() => {});
      return;
    }

    for (const info of liveEndedTabs.values()) {
      clearLiveEndedTabTimers(info);
    }
    raidSourceChannels.clear();
    scheduleAutoReloadAlarm().catch(() => {});
    return;
  }

  if (changes.twitchClientId || changes.twitchAccessToken || changes.twitchTokenExpiresAt || changes.twitchAuthLastValidatedAt) {
    runChecks();
  }

  if (changes.autoReloadEnabled || changes.autoReloadMinutes) {
    scheduleAutoReloadAlarm().catch(() => {});
  }

  if (changes.closeEndedLiveTabsEnabled || changes.closeEndedLiveTabsMode || changes.closeEndedLiveTabChannels) {
    applyLiveEndedClosePolicy().catch((error) => {
      console.warn('Falha ao aplicar a politica de fechamento ao encerrar live:', error);
    });
  }

  if (changes.lurkChannels || changes.channelBlacklist) {
    enforceBlacklistTabs().catch(() => {});
  }

  if (changes.channelMutePrefs) {
    syncMutePrefsWithTabs().catch(() => {});
  }

  if (changes.lurkChannels || changes.channelBlacklist || changes.webhookUrl) {
    runChecks();
  }
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'TWITCH_AUTH_CONNECT') {
    connectTwitchAuth()
      .then((result) => {
        sendResponse({ ok: true, ...result });
      })
      .catch((error) => {
        sendResponse({
          ok: false,
          error: error?.message || 'Falha ao conectar a Twitch.'
        });
    });
    return true;
  }

  if (message.type === 'PURGE_CHANNEL') {
    purgeTrackedChannelState(message.channel || message.channelName || '')
      .catch((error) => {
        console.warn('Falha ao remover o canal rastreado:', error);
      });
    return;
  }

  if (message.type === 'ENFORCE_BLACKLIST') {
    enforceBlacklistTabs().catch((error) => {
      console.warn('Falha ao aplicar a blacklist:', error);
    });
    return;
  }

  if (message.type === 'TWITCH_AUTH_DISCONNECT') {
    disconnectTwitchAuth()
      .then(() => sendResponse({ ok: true }))
      .catch((error) => sendResponse({ ok: false, error: error?.message || 'Falha ao desconectar a Twitch.' }));
    return true;
  }

  if (message.type === 'CLOSE_TRACKED_TABS') {
    closeTrackedTabs().catch(() => {});
    return;
  }

  if (!sender?.tab?.id) return;

  const tabId = sender.tab.id;

  if (message.type === 'RAID_DETECTED') {
    chrome.tabs.update(tabId, { active: true });
    return;
  }

  if (message.type === 'RAID_PROMPT_ACTION') {
    if (message.action === 'close') {
      const noticeWindowId = sender?.tab?.windowId ?? null;
      const noticeChannel = normalizeChannelName(
        message.toChannel || getChannelFromTwitchUrl(sender?.tab?.url || '') || lurkTabs.get(tabId) || ''
      );

      chrome.tabs.remove(tabId, () => {
        lurkTabs.delete(tabId);
        removeLiveEndedTabState(tabId);
      });

      if (noticeChannel) {
        chrome.storage.local.get(['channelBlacklist']).then(async (result) => {
          const blockedSet = new Set(normalizeChannelList(result.channelBlacklist || []));
          if (blockedSet.has(noticeChannel)) {
            await showBlacklistClosureNotice(noticeChannel, noticeWindowId);
          }
        }).catch(() => {});
      }

      return;
    }

    if (message.action === 'keep') {
      if (message.toChannel) lurkTabs.set(tabId, message.toChannel);
      removeLiveEndedTabState(tabId);
    }
    return;
  }

  if (message.type === 'LIVE_ENDED') {
    const channel = lurkTabs.get(tabId) || FELIPENOR_CHANNEL;

    chrome.storage.local.get([
      'closeEndedLiveTabsEnabled',
      'closeEndedLiveTabsMode',
      'closeEndedLiveTabChannels'
    ]).then((settings) => {
      scheduleLiveEndedTabState(tabId, {
        channel,
        ts: Date.now(),
        closeAt: Date.now() + RAID_PROMPT_CLOSE_DELAY_MS,
        expiresAt: Date.now() + RAID_PROMPT_WINDOW_MS
      }, buildLiveEndedCloseConfig(settings));
    }).catch(() => {});
  }
});

if (chrome.webNavigation?.onCommitted) {
  const handleRaidNavigation = async (details) => {
    try {
      if (details.frameId !== 0 || !details.url) return;

      const url = new URL(details.url);
      if (!url.hostname.endsWith('twitch.tv')) return;

      const parts = url.pathname.split('/').filter(Boolean);
      const newChannel = parts[0] && parts[0] !== 'videos' ? parts[0].toLowerCase() : null;
      if (!newChannel) return;

      if (!liveEndedTabs.has(details.tabId)) return;

      const info = liveEndedTabs.get(details.tabId);
      const prevChannel = info.channel;
      if (prevChannel && newChannel !== prevChannel && (Date.now() - info.ts) < RAID_PROMPT_WINDOW_MS) {
        markRaidSourceChannel(prevChannel);
        clearLiveEndedTabTimers(info);
        lurkTabs.set(details.tabId, newChannel);
        liveEndedTabs.set(details.tabId, {
          channel: newChannel,
          ts: Date.now(),
          closeAt: Date.now() + RAID_PROMPT_CLOSE_DELAY_MS,
          expiresAt: Date.now() + RAID_PROMPT_WINDOW_MS,
          autoClose: false,
          raidPromptActive: true,
          timerId: null,
          cleanupTimerId: null
        });

        try {
          await chrome.tabs.sendMessage(details.tabId, {
            type: 'SHOW_RAID_PROMPT',
            fromChannel: prevChannel,
            toChannel: newChannel
          });
        } catch {
          await injectRaidPromptOverlay(details.tabId, prevChannel, newChannel);
        }
      }
    } catch {}
  };

  chrome.webNavigation.onCommitted.addListener(handleRaidNavigation);

  if (chrome.webNavigation.onHistoryStateUpdated) {
    chrome.webNavigation.onHistoryStateUpdated.addListener(handleRaidNavigation);
  }
}

async function runChecks() {
  if (runChecksInProgress) {
    runChecksQueued = true;
    return;
  }
  runChecksInProgress = true;

  try {
    const settings = await chrome.storage.local.get([
      'extensionEnabled',
      'closeEndedLiveTabsEnabled',
      'closeEndedLiveTabsMode',
      'closeEndedLiveTabChannels'
    ]);
    if (settings.extensionEnabled === false) return;
    const closeEndedLiveConfig = buildLiveEndedCloseConfig(settings);

    await syncMutePrefsWithTabs();

    const snapshot = await getManagedChannelSnapshot();
    const { openableChannels, openableSet } = snapshot;
    await enforceBlacklistTabs(snapshot);
    await purgeTrackedTabsNotInSet(openableSet);

    const trackedChannels = normalizeChannelList([...lurkTabs.values()]).filter((channel) => openableSet.has(channel));
    const channelsToCheck = [...new Set([
      ...openableChannels,
      ...trackedChannels
    ])];

    const liveState = await fetchOfficialTwitchLiveSet(channelsToCheck);
    const channelsToOpen = channelsToCheck.filter((channel) => channel !== FELIPENOR_CHANNEL);

    await Promise.all([
      checkFelipenor(liveState, closeEndedLiveConfig),
      channelsToOpen.length > 0 ? checkUserChannels(channelsToOpen, liveState) : Promise.resolve()
    ]);

    for (const channel of [...raidSourceChannels.keys()]) {
      const normalizedChannel = normalizeChannelName(channel);
      const live = await resolveChannelLiveState(normalizedChannel, liveState);
      if (live) continue;

      try {
        await purgeTrackedChannelState(normalizedChannel);
      } catch {}
      clearRaidSourceChannel(normalizedChannel);
    }

    await Promise.all([...lurkTabs.entries()].map(async ([tabId, channel]) => {
      const live = await resolveChannelLiveState(channel, liveState);
      const normalizedChannel = normalizeChannelName(channel);
      const shouldClose = shouldCloseLiveEndedTab(normalizedChannel, closeEndedLiveConfig);
      const endedInfo = liveEndedTabs.get(tabId);

      if (live) {
        if (endedInfo) {
          removeLiveEndedTabState(tabId);
        }
        return;
      }

      if (endedInfo?.raidPromptActive) {
        return;
      }

      if (!shouldClose) {
        return;
      }

      if (endedInfo?.timerId) {
        return;
      }

      if (!endedInfo || !endedInfo.autoClose) {
        try {
          await chrome.tabs.remove(tabId);
        } catch {}
      }

      lurkTabs.delete(tabId);
      removeLiveEndedTabState(tabId);
    }));

    await syncMutePrefsWithTabs();
  } finally {
    runChecksInProgress = false;
    if (runChecksQueued) {
      runChecksQueued = false;
      runChecks().catch(() => {});
    }
  }
}

async function syncMutePrefsWithTabs() {
  const res = await chrome.storage.local.get(['channelMutePrefs']);
  const current = res.channelMutePrefs || {};
  const updated = { ...current };
  let changed = false;

  for (const [tabId, channel] of lurkTabs.entries()) {
    try {
      const tab = await chrome.tabs.get(tabId);
      const key = normalizeChannelName(channel);
      const isMuted = !!tab?.mutedInfo?.muted;
      if (updated[key] !== isMuted) {
        updated[key] = isMuted;
        changed = true;
      }
    } catch {}
  }

  if (changed) {
    await persistMutePrefs(updated);
  }
}

async function checkFelipenor(officialLiveSet = null, closeEndedLiveConfig = null) {
  if (checkFelipenor._running) return;
  checkFelipenor._running = true;

  try {
    const isLive = await resolveChannelLiveState(FELIPENOR_CHANNEL, officialLiveSet);
    const shouldCloseFelipenor = shouldCloseLiveEndedTab(FELIPENOR_CHANNEL, closeEndedLiveConfig);
    const videoTabs = await chrome.tabs.query({ url: '*://*.twitch.tv/videos/2367175351*' });
    const liveTabs = await chrome.tabs.query({ url: '*://*.twitch.tv/felipenor*' });
    const liveRootTabs = liveTabs.filter((tab) => isRootChannelUrl(tab.url, FELIPENOR_CHANNEL));
    const primaryLiveTab = liveRootTabs[0] || liveTabs[0] || null;
    const primaryVideoTab = videoTabs[0] || null;

    const closeExtras = async (tabs, keepTabId = null) => {
      for (const tab of tabs) {
        if (keepTabId && tab.id === keepTabId) continue;
        try {
          await chrome.tabs.remove(tab.id);
        } catch {}
      }

      if (keepTabId) {
        try {
          await chrome.tabs.update(keepTabId, { active: false });
        } catch {}
      }
    };

    if (isLive) {
      try {
        if (!primaryLiveTab) {
          const mutedPref = await getMutePref(FELIPENOR_CHANNEL);
          const tab = primaryVideoTab
            ? await chrome.tabs.update(primaryVideoTab.id, {
                url: FELIPENOR_URL,
                active: false,
                pinned: true
              })
            : await chrome.tabs.create({ url: FELIPENOR_URL, active: false });
          if (tab?.id) {
            await chrome.tabs.update(tab.id, { muted: mutedPref });
            lurkTabs.set(tab.id, FELIPENOR_CHANNEL);
          }
        } else {
          const mutedPref = await getMutePref(FELIPENOR_CHANNEL);
          try {
            if (isRootChannelUrl(primaryLiveTab.url, FELIPENOR_CHANNEL)) {
              await chrome.tabs.update(primaryLiveTab.id, {
                active: false,
                pinned: true,
                muted: mutedPref
              });
            } else {
              await chrome.tabs.update(primaryLiveTab.id, {
                url: FELIPENOR_URL,
                active: false,
                pinned: true
              });
              await chrome.tabs.update(primaryLiveTab.id, { muted: mutedPref });
            }
          } catch {}
          lurkTabs.set(primaryLiveTab.id, FELIPENOR_CHANNEL);
          await closeExtras(liveTabs, primaryLiveTab.id);
        }
      } catch (error) {
        console.warn('Erro ao ajustar a live do Felipenor:', error);
      }

      for (const tab of videoTabs) {
        try {
          await chrome.tabs.remove(tab.id);
        } catch {}
      }
    } else if (shouldCloseFelipenor) {
      if (!primaryVideoTab) {
        const mutedPref = await getMutePref(FELIPENOR_CHANNEL);
        const tab = await chrome.tabs.create({ url: FELIPENOR_VIDEO, active: false });
        if (tab?.id) {
          await chrome.tabs.update(tab.id, { muted: mutedPref });
        }
      } else {
        const mutedPref = await getMutePref(FELIPENOR_CHANNEL);
        try {
          if ((primaryVideoTab.url || '').includes('/videos/2367175351')) {
            await chrome.tabs.update(primaryVideoTab.id, {
              active: false,
              muted: mutedPref
            });
          } else {
            await chrome.tabs.update(primaryVideoTab.id, {
              url: FELIPENOR_VIDEO,
              active: false
            });
            await chrome.tabs.update(primaryVideoTab.id, { muted: mutedPref });
          }
        } catch {}
        await closeExtras(videoTabs, primaryVideoTab.id);
      }

      for (const tab of liveTabs) {
        try {
          await chrome.tabs.remove(tab.id);
        } catch {}
      }
    }
  } finally {
    checkFelipenor._running = false;
  }
}

async function checkUserChannels(channels, officialLiveSet = null) {
  const settings = await chrome.storage.local.get(['webhookUrl']);
  const liveStates = await Promise.all(
    channels.map(async (channel) => ({
      channel,
      isLive: await resolveChannelLiveState(channel, officialLiveSet)
    }))
  );

  for (const { channel, isLive } of liveStates) {
    if (!isLive) continue;

    try {
      const channelUrl = `https://www.twitch.tv/${channel}`;
      const tabs = await chrome.tabs.query({ url: `*://*.twitch.tv/${channel}*` });
      const liveRootTabs = tabs.filter((tab) => isRootChannelUrl(tab.url, channel));
      const primaryTab = liveRootTabs[0] || tabs[0] || null;

      if (!primaryTab) {
        const mutedPref = await getMutePref(channel);
        const tab = await chrome.tabs.create({ url: channelUrl, active: false, pinned: true });
        if (tab?.id) {
          await chrome.tabs.update(tab.id, { muted: mutedPref });
          lurkTabs.set(tab.id, channel);
        }

        if (settings.webhookUrl) {
          sendDiscordNotification(settings.webhookUrl, channel);
        }
        continue;
      }

      const mutedPref = await getMutePref(channel);
      try {
        if (isRootChannelUrl(primaryTab.url, channel)) {
          await chrome.tabs.update(primaryTab.id, {
            active: false,
            pinned: true,
            muted: mutedPref
          });
        } else {
          await chrome.tabs.update(primaryTab.id, {
            url: channelUrl,
            active: false,
            pinned: true
          });
          await chrome.tabs.update(primaryTab.id, { muted: mutedPref });
        }
      } catch {}

      lurkTabs.set(primaryTab.id, channel);

      for (const tab of tabs) {
        if (tab.id === primaryTab.id) continue;
        try {
          await chrome.tabs.remove(tab.id);
        } catch {}
      }
    } catch (error) {
      console.warn(`Erro ao ajustar o canal ${channel}:`, error);
    }
  }
}

async function sendDiscordNotification(webhookUrl, channel) {
  try {
    await fetch(webhookUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        content: `🔴 **ShadowLurk Alert**: O canal **${channel}** está ao vivo! Abrindo lurk...`
      })
    });
  } catch (error) {
    console.error('Erro ao enviar webhook:', error);
  }
}

async function isChannelLive(channelName) {
  const login = normalizeChannelName(channelName);

  try {
    const hls = await fetchWithTimeout(`https://usher.ttvnw.net/api/channel/hls/${login}.m3u8?client_id=kimne78kx3ncx6brgo4mv6wki5h1ko&allow_source=true`, {
      method: 'GET',
      cache: 'no-store'
    });

    if (hls.ok) {
      const text = await hls.text();
      if (text.includes('#EXTM3U')) return true;
    }
  } catch {}

  try {
    const gqlRes = await fetchWithTimeout('https://gql.twitch.tv/gql', {
      method: 'POST',
      headers: {
        'Client-ID': 'kimne78kx3ncx6brgo4mv6wki5h1ko',
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        query: 'query($login:String){user(login:$login){stream{type}}}',
        variables: { login }
      })
    });

    if (gqlRes.ok) {
      const data = await gqlRes.json();
      if (data?.data?.user?.stream) return true;
    }
  } catch {}

  try {
    const response = await fetchWithTimeout(`https://www.twitch.tv/${login}`, {
      cache: 'no-store',
      headers: {
        'Cache-Control': 'no-cache',
        'Pragma': 'no-cache',
        Accept: 'text/html'
      }
    });

    const text = await response.text();
    const patterns = [
      /"isLiveBroadcast"\s*:\s*true/i,
      /"isLive"\s*:\s*true/i,
      /summary_live_video/i,
      /"stream":\s*\{[\s\S]*?"type"\s*:\s*"live"/i,
      /aria-label="Ao vivo"/i,
      /aria-label="Live"/i
    ];
    return patterns.some((pattern) => pattern.test(text));
  } catch (error) {
    console.error(`Erro ao verificar canal ${channelName}:`, error);
    return false;
  }
}

async function isChannelLiveReliable(channelName, attempts = 2) {
  for (let attempt = 0; attempt < attempts; attempt += 1) {
    if (await isChannelLive(channelName)) {
      return true;
    }

    if (attempt < attempts - 1) {
      await delay(750);
    }
  }

  return false;
}
