document.addEventListener('DOMContentLoaded', () => {
  const settingsBtn = document.getElementById('settingsBtn');
  const settingsModal = document.getElementById('settingsModal');
  const closeSettingsBtn = document.getElementById('closeSettingsBtn');
  const channelInput = document.getElementById('channelInput');
  const blacklistInput = document.getElementById('blacklistInput');
  const webhookInput = document.getElementById('webhookInput');
  const twitchAuthBtn = document.getElementById('twitchAuthBtn');
  const twitchApiStatus = document.getElementById('twitchApiStatus');
  const addChannelBtn = document.getElementById('addChannelBtn');
  const channelList = document.getElementById('channelList');
  const addBlacklistBtn = document.getElementById('addBlacklistBtn');
  const blacklistList = document.getElementById('blacklistList');
  const blacklistStatus = document.getElementById('blacklistStatus');
  const exportChannelsBtn = document.getElementById('exportChannelsBtn');
  const importChannelsBtn = document.getElementById('importChannelsBtn');
  const importChannelsInput = document.getElementById('importChannelsInput');
  const favoritesTransferStatus = document.getElementById('favoritesTransferStatus');
  const toggleExtension = document.getElementById('toggleExtension');
  const partnerList = document.getElementById('partnerList');
  const applyFixedBtn = document.getElementById('applyFixedBtn');
  const languageSelect = document.getElementById('languageSelect');
  const autoReloadToggle = document.getElementById('autoReloadToggle');
  const autoReloadMinutes = document.getElementById('autoReloadMinutes');
  const autoReloadTimer = document.getElementById('autoReloadTimer');
  const closeEndedLiveToggle = document.getElementById('closeEndedLiveToggle');
  const closeEndedLiveMode = document.getElementById('closeEndedLiveMode');
  const closeEndedLiveList = document.getElementById('closeEndedLiveList');
  const closeEndedLiveStatus = document.getElementById('closeEndedLiveStatus');
  const disablePrompt = document.getElementById('disablePrompt');
  const keepOnlyBtn = document.getElementById('keepOnlyBtn');
  const closeAllBtn = document.getElementById('closeAllBtn');

  const PARTNER_CHANNELS = [
    'Felipenor',
    'WaferKon',
    'kirito_nautilus',
    'baluartetm',
    'kiolhawuz',
    'alphaieslis',
    'rafael_1225',
    'b3lialtv',
    'ruffusthewolfu',
    'SplokBr',
    'Titan_BR_Play',
    'TobitoKaabe',
    'nagi_edits1',
    'Extreme_SL',
    'GaboAkk',
    'rarutosusto'
  ];

  const LANGUAGE_OPTIONS = [
    { value: 'auto', label: 'Auto' },
    { value: 'pt-BR', label: 'Português (Brasil)' },
    { value: 'en', label: 'English' },
    { value: 'es', label: 'Español' },
    { value: 'fr', label: 'Français' },
    { value: 'de', label: 'Deutsch' },
    { value: 'it', label: 'Italiano' },
    { value: 'ja', label: '日本語' },
    { value: 'ko', label: '한국어' },
    { value: 'ru', label: 'Русский' },
    { value: 'zh-CN', label: '中文（简体）' },
    { value: 'zh-TW', label: '中文（繁體）' },
    { value: 'ar', label: 'العربية' },
    { value: 'hi', label: 'हिन्दी' },
    { value: 'tr', label: 'Türkçe' },
    { value: 'nl', label: 'Nederlands' },
    { value: 'pl', label: 'Polski' },
    { value: 'id', label: 'Bahasa Indonesia' },
    { value: 'vi', label: 'Tiếng Việt' },
    { value: 'pt-PT', label: 'Português (Portugal)' }
  ];

  const BASE_TEXTS = {
    subtitle: 'Lurk automático e ferramentas para Twitch',
    settingsButtonTitle: 'Abrir configurações',
    statusLabel: 'ShadowLurk ativo:',
    languageLabel: 'Idioma da interface',
    languageHint: 'Escolha como a interface do popup vai aparecer.',
    languageAutoOption: 'Automático',
    adblockWarning: '⚠️ Por favor, desative o AdBlock para apoiar os canais.',
    settingsTitle: 'Configurações',
    webhookPlaceholder: 'Discord Webhook URL',
    settingsModalTitle: 'Configurações avançadas',
    settingsModalHint: 'Recarga automática, fechamento de lives e conexão oficial da Twitch ficam aqui.',
    closeSettingsButton: 'Fechar configurações',
    twitchApiTitle: 'Conexão oficial com a Twitch',
    twitchApiHint: 'Clique para abrir a Twitch e autorizar a ShadowLurk. Se você não conectar, a extensão continua usando o modo padrão.',
    twitchAuthConnectButton: 'Conectar com a Twitch',
    twitchAuthDisconnectButton: 'Desconectar da Twitch',
    twitchStatusDisconnected: 'Desconectado',
    twitchStatusDisconnecting: 'Desconectando...',
    twitchStatusConnecting: 'Conectando...',
    twitchStatusConnected: 'Conectado',
    twitchStatusWarning: 'Aviso',
    twitchStatusAwaitingValidation: 'Aguardando validação',
    twitchStatusError: 'Falha na conexão',
    myChannelsTitle: 'Meus Canais de Lurk',
    channelPlaceholder: 'Nome do canal (ex: felipenor)',
    addButton: 'Adicionar',
    favoritesTransferHint: 'Exporte seus favoritos para restaurar tudo mais rápido depois das atualizações.',
    exportFavoritesButton: 'Exportar favoritos',
    importFavoritesButton: 'Importar favoritos',
    favoritesStatusReady: 'Salve ou restaure seus favoritos em um arquivo.',
    favoritesStatusExported: 'Arquivo exportado com sucesso.',
    favoritesStatusImported: 'Favoritos importados com sucesso.',
    favoritesStatusEmpty: 'Nenhum favorito válido foi encontrado no arquivo.',
    favoritesStatusInvalid: 'Não foi possível importar este arquivo.',
    blacklistTitle: 'Blacklist',
    blacklistHint: 'Digite apenas canais comuns que a extensão não deve abrir automaticamente. Canais fixos e favoritos são protegidos.',
    blacklistPlaceholder: 'Nome do canal para bloquear',
    blacklistEmptyText: 'Nenhum canal na blacklist ainda.',
    blacklistStatusReady: 'Use a blacklist apenas para canais comuns.',
    blacklistStatusAdded: 'Canal adicionado na blacklist.',
    blacklistStatusAlreadyAdded: 'Esse canal já está na blacklist.',
    blacklistStatusRemoved: 'Canal removido da blacklist.',
    blacklistStatusInvalid: 'Digite um nome de canal válido.',
    blacklistStatusFavoriteBlocked: 'Esse canal está nos favoritos. Remova pelo X da lista de favoritos primeiro.',
    blacklistStatusFixedBlocked: 'Esse canal está nos fixos. Apenas o Felipenor pode remover em uma atualização futura.',
    blacklistStatusSaveError: 'Não foi possível salvar a blacklist agora. Tente novamente.',
    fixedTitle: 'Canais Fixos',
    fixedCtaTitle: 'Quer virar fixo?',
    fixedCtaText: 'Abra o formulário e envie sua inscrição para entrar na lista da ShadowLurk.',
    fixedCtaButton: 'Abrir formulário',
    autoReloadTitle: 'Recarga automática das lives',
    autoReloadHint: 'Opcional. Recarrega as abas abertas dos canais fixos e favoritos no intervalo escolhido. Desativado por padrão para economizar recursos.',
    autoReloadIntervalLabel: 'Intervalo em minutos',
    autoReloadMinutesUnit: 'min',
    autoReloadStatusLabel: 'Timer',
    autoReloadDisabledText: 'Desativada',
    autoReloadActiveText: 'Ativa',
    autoReloadNextText: 'Próxima recarga em',
    autoReloadReloadingText: 'Recarregando agora',
    closeEndedLiveTitle: 'Fechar guias ao encerrar live',
    closeEndedLiveHint: 'Opcional. Desativado por padrÃ£o. Se ativar, a extensÃ£o pode fechar a guia quando a live terminar.',
    closeEndedLiveModeLabel: 'Modo de fechamento',
    closeEndedLiveModeAll: 'Fechar todas as lives encerradas',
    closeEndedLiveModeSelected: 'Somente canais escolhidos',
    closeEndedLiveListHint: 'Escolha os canais que devem ser fechados quando a live terminar. A lista atualiza em tempo real. Se nada estiver marcado no modo selecionado, as lives continuam abertas.',
    closeEndedLiveStatusDisabled: 'Desativado',
    closeEndedLiveStatusAll: 'Ativo: fechando todas as lives encerradas',
    closeEndedLiveStatusSelectedEmpty: 'Ativo: nenhum canal selecionado ainda',
    closeEndedLiveStatusSelectedOne: 'Ativo: 1 canal selecionado',
    closeEndedLiveStatusSelectedMany: 'Ativo: {count} canais selecionados',
    closeEndedLiveEmpty: 'Nenhum canal disponÃ­vel para seleÃ§Ã£o agora.',
    disablePromptTitle: 'Desligar ShadowLurk?',
    disablePromptBody: 'Você quer apenas desligar a extensão ou desligar e fechar todas as lives abertas?',
    keepOnlyButton: 'Só desligar a extensão',
    closeAllButton: 'Desligar e fechar todas as lives',
    creatorTitle: 'Criador: Felipenor',
    creatorDescription: 'Esta extensão ajuda a manter o canal do Felipenor online. Deixe o navegador aberto para apoiar!',
    twitchButton: '📺 Twitch Felipenor',
    youtubeButton: '▶️ YouTube',
    bioButton: '🔗 Linkbio',
    supportTitle: 'Apoie o desenvolvimento',
    pixButton: '💸 Doar via Pix',
    paypalButton: '💲 Doar via PayPal',
    muteLabel: 'Mutar ao abrir',
    removeChannel: 'Remover canal'
  };

  const RTL_LANGUAGES = new Set(['ar', 'fa', 'he', 'ur']);
  const APPLY_FORM_URL = chrome.runtime.getURL('apply.html');
  const AUTO_RELOAD_ALARM = 'refreshTrackedLiveTabs';
  const FAVORITES_EXPORT_VERSION = 1;

  let currentChannels = [];
  let channelMutePrefs = {};
  let currentLanguagePreference = 'auto';
  let currentResolvedLanguage = 'pt-BR';
  let localizedTexts = { ...BASE_TEXTS };
  let localizationToken = 0;
  let disablePromptResolver = null;
  let autoReloadTimerHandle = null;
  let twitchApiBusy = false;
  let twitchAuthState = { isConnected: false, login: '', needsAttention: false };
  let favoritesTransferStatusKey = 'favoritesStatusReady';
  let favoritesTransferStatusTone = 'info';
  let blacklistStatusKey = 'blacklistStatusReady';
  let blacklistStatusTone = 'info';
  let blacklistedChannels = [];
  let closeEndedLiveTabsEnabled = false;
  let closeEndedLiveTabsMode = 'all';
  let closeEndedLiveTabChannels = [];
  const translationCache = new Map();
  const PARTNER_CHANNEL_SET = new Set(PARTNER_CHANNELS.map((channel) => normalizeChannel(channel)));

  bindEvents();
  chrome.storage.onChanged.addListener((changes, areaName) => {
    if (areaName !== 'local') return;

    if (changes.lurkChannels) {
      currentChannels = normalizeChannelList(changes.lurkChannels.newValue || []);
      channelMutePrefs = buildFavoriteMutePrefs(currentChannels, channelMutePrefs);
      renderLists();
    }

    if (changes.channelMutePrefs) {
      channelMutePrefs = buildFavoriteMutePrefs(currentChannels, changes.channelMutePrefs.newValue || {});
      renderLists();
    }

    if (changes.channelBlacklist) {
      blacklistedChannels = filterProtectedBlacklistChannels(changes.channelBlacklist.newValue || []);
      renderBlacklistList();
    }

    if (changes.closeEndedLiveTabsEnabled) {
      closeEndedLiveTabsEnabled = changes.closeEndedLiveTabsEnabled.newValue === true;
      renderCloseEndedLiveControls();
    }

    if (changes.closeEndedLiveTabsMode) {
      closeEndedLiveTabsMode = normalizeCloseEndedLiveMode(changes.closeEndedLiveTabsMode.newValue);
      renderCloseEndedLiveControls();
    }

    if (changes.closeEndedLiveTabChannels) {
      closeEndedLiveTabChannels = normalizeChannelList(changes.closeEndedLiveTabChannels.newValue || []);
      renderCloseEndedLiveControls();
    }

    if (changes.autoReloadEnabled || changes.autoReloadMinutes || changes.autoReloadNextAt) {
      updateAutoReloadControls();
      renderAutoReloadTimer().catch(() => {});
    }
  });

  initialize().catch((error) => {
    console.error('Erro ao inicializar a popup:', error);
  });

  function bindEvents() {
    settingsBtn.addEventListener('click', openSettingsModal);
    closeSettingsBtn.addEventListener('click', closeSettingsModal);
    settingsModal.addEventListener('click', (event) => {
      if (event.target === settingsModal) {
        closeSettingsModal();
      }
    });

    webhookInput.addEventListener('change', async () => {
      await chrome.storage.local.set({ webhookUrl: webhookInput.value.trim() });
    });

    addChannelBtn.addEventListener('click', () => {
      const channel = normalizeChannel(channelInput.value);
      if (channel) {
        addChannel(channel);
        channelInput.value = '';
      }
    });

    channelInput.addEventListener('keydown', (event) => {
      if (event.key !== 'Enter') return;
      const channel = normalizeChannel(channelInput.value);
      if (channel) {
        addChannel(channel);
        channelInput.value = '';
      }
    });

    addBlacklistBtn.addEventListener('click', async () => {
      const channel = normalizeChannel(blacklistInput.value);
      if (channel) {
        const added = await addBlacklistChannel(channel);
        if (added) {
          blacklistInput.value = '';
        }
      }
    });

    blacklistInput.addEventListener('keydown', async (event) => {
      if (event.key !== 'Enter') return;
      const channel = normalizeChannel(blacklistInput.value);
      if (channel) {
        const added = await addBlacklistChannel(channel);
        if (added) {
          blacklistInput.value = '';
        }
      }
    });

    toggleExtension.addEventListener('change', async () => {
      if (toggleExtension.checked) {
        await chrome.storage.local.set({ extensionEnabled: true });
        return;
      }

      const choice = await promptDisableAction();
      if (choice === 'keep') {
        await chrome.storage.local.set({ extensionEnabled: false });
        return;
      }

      if (choice === 'close') {
        try {
          await chrome.runtime.sendMessage({ type: 'CLOSE_TRACKED_TABS' });
        } catch {}
        await chrome.storage.local.set({ extensionEnabled: false });
        return;
      }

      toggleExtension.checked = true;
    });

    applyFixedBtn.addEventListener('click', openFixedApplication);
    exportChannelsBtn.addEventListener('click', exportFavoriteChannels);
    importChannelsBtn.addEventListener('click', () => {
      importChannelsInput.click();
    });
    importChannelsInput.addEventListener('change', () => {
      importFavoriteChannels().catch(() => {
        setFavoritesTransferStatus('favoritesStatusInvalid', 'error');
      });
    });

    languageSelect.addEventListener('change', async () => {
      await setLanguagePreference(languageSelect.value);
    });

    autoReloadToggle.addEventListener('change', async () => {
      await chrome.storage.local.set({ autoReloadEnabled: autoReloadToggle.checked });
      updateAutoReloadControls();
      renderAutoReloadTimer().catch(() => {});
    });

    autoReloadMinutes.addEventListener('change', () => {
      persistAutoReloadMinutes({ commit: true }).catch(() => {});
    });

    autoReloadMinutes.addEventListener('blur', () => {
      persistAutoReloadMinutes({ commit: true }).catch(() => {});
    });

    autoReloadMinutes.addEventListener('keydown', (event) => {
      if (event.key !== 'Enter') return;
      persistAutoReloadMinutes({ commit: true }).catch(() => {});
    });

    closeEndedLiveToggle.addEventListener('change', async () => {
      closeEndedLiveTabsEnabled = closeEndedLiveToggle.checked;
      await chrome.storage.local.set({ closeEndedLiveTabsEnabled: closeEndedLiveTabsEnabled });
      renderCloseEndedLiveControls();
    });

    closeEndedLiveMode.addEventListener('change', async () => {
      closeEndedLiveTabsMode = normalizeCloseEndedLiveMode(closeEndedLiveMode.value);
      await chrome.storage.local.set({ closeEndedLiveTabsMode: closeEndedLiveTabsMode });
      renderCloseEndedLiveControls();
    });

    twitchAuthBtn.addEventListener('click', toggleTwitchAuth);

    keepOnlyBtn.addEventListener('click', () => resolveDisableAction('keep'));
    closeAllBtn.addEventListener('click', () => resolveDisableAction('close'));

    disablePrompt.addEventListener('click', (event) => {
      if (event.target === disablePrompt) {
        resolveDisableAction(null);
      }
    });

    document.addEventListener('keydown', (event) => {
      if (event.key === 'Escape' && !settingsModal.hidden) {
        closeSettingsModal();
        return;
      }

      if (event.key === 'Escape' && !disablePrompt.hidden) {
        resolveDisableAction(null);
      }
    });
  }

  async function initialize() {
    const result = await chrome.storage.local.get([
      'lurkChannels',
      'extensionEnabled',
      'webhookUrl',
      'channelMutePrefs',
      'channelBlacklist',
      'uiLanguage',
      'autoReloadEnabled',
      'autoReloadMinutes',
      'autoReloadNextAt',
      'closeEndedLiveTabsEnabled',
      'closeEndedLiveTabsMode',
      'closeEndedLiveTabChannels'
    ]);
    currentChannels = normalizeChannelList(result.lurkChannels || []);
    channelMutePrefs = buildFavoriteMutePrefs(currentChannels, result.channelMutePrefs || {});
    blacklistedChannels = filterProtectedBlacklistChannels(result.channelBlacklist || []);
    closeEndedLiveTabsEnabled = result.closeEndedLiveTabsEnabled === true;
    closeEndedLiveTabsMode = normalizeCloseEndedLiveMode(result.closeEndedLiveTabsMode);
    closeEndedLiveTabChannels = normalizeChannelList(result.closeEndedLiveTabChannels || []);
    toggleExtension.checked = result.extensionEnabled !== false;
    webhookInput.value = result.webhookUrl || '';
    autoReloadToggle.checked = result.autoReloadEnabled === true;
    autoReloadMinutes.value = String(sanitizeAutoReloadMinutes(result.autoReloadMinutes));

    const nextDefaults = {};
    if (typeof result.autoReloadEnabled === 'undefined') {
      nextDefaults.autoReloadEnabled = false;
    }
    if (typeof result.autoReloadMinutes === 'undefined') {
      nextDefaults.autoReloadMinutes = 5;
    }
    if (typeof result.autoReloadNextAt === 'undefined') {
      nextDefaults.autoReloadNextAt = null;
    }
    if (typeof result.channelBlacklist === 'undefined') {
      nextDefaults.channelBlacklist = [];
    }
    if (typeof result.closeEndedLiveTabsEnabled === 'undefined') {
      nextDefaults.closeEndedLiveTabsEnabled = false;
    }
    if (typeof result.closeEndedLiveTabsMode === 'undefined') {
      nextDefaults.closeEndedLiveTabsMode = 'all';
    }
    if (typeof result.closeEndedLiveTabChannels === 'undefined') {
      nextDefaults.closeEndedLiveTabChannels = [];
    }
    if (Object.keys(nextDefaults).length > 0) {
      await chrome.storage.local.set(nextDefaults);
    }

    const cleanedStorage = {};
    if (currentChannels.length !== (result.lurkChannels || []).length) {
      cleanedStorage.lurkChannels = currentChannels;
    }
    if (blacklistedChannels.length !== (result.channelBlacklist || []).length) {
      cleanedStorage.channelBlacklist = blacklistedChannels;
    }
    if (Object.keys(channelMutePrefs).length !== Object.keys(result.channelMutePrefs || {}).length) {
      cleanedStorage.channelMutePrefs = channelMutePrefs;
    }
    if (Object.keys(cleanedStorage).length > 0) {
      await chrome.storage.local.set(cleanedStorage);
    }

    await setLanguagePreference(result.uiLanguage || 'auto', { persist: false });
    await renderTwitchApiPanel();
    updateAutoReloadControls();
    renderCloseEndedLiveControls();
    renderAutoReloadTimer().catch(() => {});
    startAutoReloadTimerLoop();
    renderTwitchApiPanel().catch(() => {});
    renderBlacklistStatus();
  }

  function normalizeChannel(value) {
    return value.trim().toLowerCase();
  }

  function normalizeChannelList(channels) {
    return [...new Set((channels || []).map((channel) => normalizeChannel(String(channel || ''))).filter(Boolean))];
  }

  function isFixedChannel(channel) {
    return PARTNER_CHANNEL_SET.has(normalizeChannel(channel));
  }

  function isProtectedBlacklistChannel(channel) {
    const normalized = normalizeChannel(channel);
    return currentChannels.includes(normalized) || isFixedChannel(normalized);
  }

  function getBlacklistProtectionReason(channel) {
    const normalized = normalizeChannel(channel);
    if (isFixedChannel(normalized)) return 'fixed';
    if (currentChannels.includes(normalized)) return 'favorite';
    return null;
  }

  function filterProtectedBlacklistChannels(channels, favoritesList = currentChannels) {
    const favoritesSet = new Set(normalizeChannelList(favoritesList));
    return normalizeChannelList(channels).filter((channel) => !favoritesSet.has(channel) && !isFixedChannel(channel));
  }

  function normalizeCloseEndedLiveMode(mode) {
    return mode === 'selected' ? 'selected' : 'all';
  }

  function buildFavoriteMutePrefs(channels, prefs = {}) {
    const nextPrefs = {};
    for (const channel of normalizeChannelList(channels)) {
      const key = channel.toLowerCase();
      if (typeof prefs[key] === 'boolean') {
        nextPrefs[key] = prefs[key];
      }
    }
    return nextPrefs;
  }

  function buildCloseEndedLiveChannelOptions() {
    return normalizeChannelList([...PARTNER_CHANNELS, ...currentChannels]);
  }

  function getCloseEndedLiveStatusText() {
    const availableCount = buildCloseEndedLiveChannelOptions().length;
    if (availableCount === 0) {
      return localizedTexts.closeEndedLiveEmpty || '';
    }

    if (!closeEndedLiveTabsEnabled) {
      return localizedTexts.closeEndedLiveStatusDisabled || '';
    }

    if (closeEndedLiveTabsMode !== 'selected') {
      return localizedTexts.closeEndedLiveStatusAll || '';
    }

    const selectedCount = closeEndedLiveTabChannels.length;
    if (selectedCount <= 0) {
      return localizedTexts.closeEndedLiveStatusSelectedEmpty || '';
    }

    if (selectedCount === 1) {
      return localizedTexts.closeEndedLiveStatusSelectedOne || '';
    }

    return (localizedTexts.closeEndedLiveStatusSelectedMany || '').replace('{count}', String(selectedCount));
  }

  function updateCloseEndedLiveControls() {
    if (!closeEndedLiveToggle || !closeEndedLiveMode) return;

    const isEnabled = closeEndedLiveTabsEnabled === true;
    closeEndedLiveToggle.checked = isEnabled;
    closeEndedLiveMode.disabled = !isEnabled;
    closeEndedLiveMode.value = normalizeCloseEndedLiveMode(closeEndedLiveTabsMode);

    const settingsRow = closeEndedLiveMode.closest('.close-ended-live-settings');
    settingsRow?.classList.toggle('is-disabled', !isEnabled);
  }

  async function setCloseEndedLiveChannelSelection(channelName, isSelected) {
    const normalized = normalizeChannel(channelName);
    if (!normalized) return;

    const nextSelection = new Set(normalizeChannelList(closeEndedLiveTabChannels));
    if (isSelected) {
      nextSelection.add(normalized);
    } else {
      nextSelection.delete(normalized);
    }

    closeEndedLiveTabChannels = [...nextSelection];
    await chrome.storage.local.set({ closeEndedLiveTabChannels });
    renderCloseEndedLiveControls();
  }

  function renderCloseEndedLiveControls() {
    if (!closeEndedLiveToggle || !closeEndedLiveMode || !closeEndedLiveList) return;

    updateCloseEndedLiveControls();

    if (closeEndedLiveStatus) {
      closeEndedLiveStatus.textContent = getCloseEndedLiveStatusText();
    }

    const listWrap = closeEndedLiveList.closest('.close-ended-live-list-wrap');
    const shouldShowList = closeEndedLiveTabsEnabled === true && closeEndedLiveTabsMode === 'selected';
    if (listWrap) {
      listWrap.hidden = !shouldShowList;
    }

    closeEndedLiveList.innerHTML = '';
    if (!shouldShowList) return;

    const options = buildCloseEndedLiveChannelOptions();
    if (options.length === 0) {
      const li = document.createElement('li');
      li.className = 'close-ended-live-empty-item';
      li.textContent = localizedTexts.closeEndedLiveEmpty || '';
      closeEndedLiveList.appendChild(li);
      return;
    }

    const selectedSet = new Set(closeEndedLiveTabChannels);
    options.forEach((channel) => {
      const li = document.createElement('li');

      const label = document.createElement('label');
      label.className = 'close-ended-live-item-label';

      const checkbox = document.createElement('input');
      checkbox.type = 'checkbox';
      checkbox.checked = selectedSet.has(channel);
      checkbox.addEventListener('change', () => {
        setCloseEndedLiveChannelSelection(channel, checkbox.checked).catch(() => {});
      });

      const name = document.createElement('span');
      name.className = 'close-ended-live-item-name';
      name.textContent = channel;

      label.appendChild(checkbox);
      label.appendChild(name);
      li.appendChild(label);

      if (PARTNER_CHANNEL_SET.has(channel)) {
        const badge = document.createElement('span');
        badge.className = 'close-ended-live-item-badge';
        badge.textContent = isFixedChannel(channel) ? 'Fixo' : 'Favorito';
        li.appendChild(badge);
      }

      closeEndedLiveList.appendChild(li);
    });
  }

  function normalizeLanguageCode(code) {
    const raw = String(code || '').trim();
    if (!raw) return 'pt-BR';

    const lower = raw.toLowerCase();
    if (lower === 'auto') return 'auto';
    if (lower.startsWith('pt')) return lower.includes('pt-pt') ? 'pt-PT' : 'pt-BR';
    if (lower.startsWith('zh')) {
      if (lower.includes('tw') || lower.includes('hk')) return 'zh-TW';
      return 'zh-CN';
    }

    const base = lower.split('-')[0];
    return base || 'en';
  }

  function getBrowserLanguage() {
    return normalizeLanguageCode(chrome.i18n?.getUILanguage?.() || navigator.language || 'pt-BR');
  }

  function resolveEffectiveLanguage(preference) {
    if (!preference || preference === 'auto') {
      return getBrowserLanguage();
    }
    return normalizeLanguageCode(preference);
  }

  function toGoogleTarget(language) {
    if (language === 'pt-BR' || language === 'pt-PT') return 'pt';
    return language;
  }

  async function setLanguagePreference(preference, options = {}) {
    const { persist = true } = options;

    currentLanguagePreference = preference || 'auto';
    currentResolvedLanguage = resolveEffectiveLanguage(currentLanguagePreference);
    const token = ++localizationToken;

    localizedTexts = await buildLocalizedTexts(currentResolvedLanguage);
    if (token !== localizationToken) return;

    applyLocalizedTexts();
    renderLanguageOptions();
    renderLists();

    if (persist) {
      await chrome.storage.local.set({ uiLanguage: currentLanguagePreference });
    }
  }

  async function buildLocalizedTexts(targetLanguage) {
    if (targetLanguage === 'pt-BR') {
      return { ...BASE_TEXTS };
    }

    const translatedEntries = await Promise.all(
      Object.entries(BASE_TEXTS).map(async ([key, text]) => [key, await translateText(text, targetLanguage)])
    );

    return Object.fromEntries(translatedEntries);
  }

  async function translateText(text, targetLanguage) {
    if (!text || targetLanguage === 'pt-BR') return text;

    const cacheKey = `${targetLanguage}::${text}`;
    if (translationCache.has(cacheKey)) {
      return translationCache.get(cacheKey);
    }

    const googleTarget = toGoogleTarget(targetLanguage);

    try {
      const url = new URL('https://translate.googleapis.com/translate_a/single');
      url.searchParams.set('client', 'gtx');
      url.searchParams.set('sl', 'pt');
      url.searchParams.set('tl', googleTarget);
      url.searchParams.set('dt', 't');
      url.searchParams.set('q', text);

      const response = await fetch(url.toString(), { cache: 'no-store' });
      if (!response.ok) throw new Error(`Translate HTTP ${response.status}`);

      const data = await response.json();
      const translated = Array.isArray(data?.[0])
        ? data[0].map((segment) => segment?.[0] || '').join('')
        : text;
      const finalText = translated || text;

      translationCache.set(cacheKey, finalText);
      return finalText;
    } catch (error) {
      console.warn('Falha ao traduzir texto da popup:', error);
      translationCache.set(cacheKey, text);
      return text;
    }
  }

  function applyLocalizedTexts() {
    document.documentElement.lang = currentResolvedLanguage;
    const direction = RTL_LANGUAGES.has(currentResolvedLanguage) ? 'rtl' : 'ltr';
    document.documentElement.dir = direction;
    document.body.dir = direction;

    document.querySelectorAll('[data-i18n]').forEach((element) => {
      const key = element.dataset.i18n;
      if (localizedTexts[key]) {
        element.textContent = localizedTexts[key];
      }
    });

    document.querySelectorAll('[data-i18n-placeholder]').forEach((element) => {
      const key = element.dataset.i18nPlaceholder;
      if (localizedTexts[key]) {
        element.setAttribute('placeholder', localizedTexts[key]);
      }
    });

    document.querySelectorAll('[data-i18n-title]').forEach((element) => {
      const key = element.dataset.i18nTitle;
      if (localizedTexts[key]) {
        element.setAttribute('title', localizedTexts[key]);
        element.setAttribute('aria-label', localizedTexts[key]);
      }
    });

    languageSelect.setAttribute('aria-label', localizedTexts.languageLabel);
    autoReloadToggle.setAttribute('aria-label', localizedTexts.autoReloadTitle);
    autoReloadToggle.title = localizedTexts.autoReloadTitle;
    applyFixedBtn.title = localizedTexts.fixedCtaButton;
    exportChannelsBtn.title = localizedTexts.exportFavoritesButton;
    importChannelsBtn.title = localizedTexts.importFavoritesButton;
    renderFavoritesTransferStatus();
    renderBlacklistStatus();
    renderTwitchApiPanel().catch(() => {});
    renderAutoReloadTimer().catch(() => {});
  }

  function renderLanguageOptions() {
    languageSelect.innerHTML = '';

    for (const optionDef of LANGUAGE_OPTIONS) {
      const option = document.createElement('option');
      option.value = optionDef.value;
      option.textContent = optionDef.value === 'auto' ? localizedTexts.languageAutoOption : optionDef.label;
      languageSelect.appendChild(option);
    }

    languageSelect.value = currentLanguagePreference;
  }

  function renderLists() {
    renderList(currentChannels);
    renderBlacklistList();
    renderPartnerList();
    renderCloseEndedLiveControls();
  }

  function renderFavoritesTransferStatus() {
    if (!favoritesTransferStatus) return;

    favoritesTransferStatus.textContent = localizedTexts[favoritesTransferStatusKey] || '';
    favoritesTransferStatus.classList.remove('is-success', 'is-error');

    if (favoritesTransferStatusTone === 'success') {
      favoritesTransferStatus.classList.add('is-success');
      return;
    }

    if (favoritesTransferStatusTone === 'error') {
      favoritesTransferStatus.classList.add('is-error');
    }
  }

  function setFavoritesTransferStatus(messageKey, tone = 'info') {
    favoritesTransferStatusKey = messageKey;
    favoritesTransferStatusTone = tone;
    renderFavoritesTransferStatus();
  }

  function renderBlacklistStatus() {
    if (!blacklistStatus) return;

    blacklistStatus.textContent = localizedTexts[blacklistStatusKey] || '';
    blacklistStatus.classList.remove('is-success', 'is-error');

    if (blacklistStatusTone === 'success') {
      blacklistStatus.classList.add('is-success');
      return;
    }

    if (blacklistStatusTone === 'error') {
      blacklistStatus.classList.add('is-error');
    }
  }

  function setBlacklistStatus(messageKey, tone = 'info') {
    blacklistStatusKey = messageKey;
    blacklistStatusTone = tone;
    renderBlacklistStatus();
  }

  function buildFavoritesExportPayload() {
    const channels = normalizeChannelList(currentChannels);
    return {
      app: 'ShadowLurk',
      version: FAVORITES_EXPORT_VERSION,
      exportedAt: new Date().toISOString(),
      lurkChannels: channels,
      channelMutePrefs: buildFavoriteMutePrefs(channels, channelMutePrefs),
      channelBlacklist: filterProtectedBlacklistChannels(blacklistedChannels, channels)
    };
  }

  function downloadTextFile(filename, content, mimeType = 'application/json') {
    const blob = new Blob([content], { type: `${mimeType};charset=utf-8` });
    const objectUrl = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = objectUrl;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    link.remove();
    setTimeout(() => URL.revokeObjectURL(objectUrl), 1000);
  }

  function parseImportedFavorites(text) {
    const trimmed = `${text || ''}`.trim();
    if (!trimmed) {
      return { channels: [], channelMutePrefs: {} };
    }

    if (trimmed.startsWith('{') || trimmed.startsWith('[')) {
      const parsed = JSON.parse(trimmed);

      if (Array.isArray(parsed)) {
        return {
          channels: normalizeChannelList(parsed),
          channelMutePrefs: {}
        };
      }

      const channels = normalizeChannelList(
        parsed?.lurkChannels || parsed?.channels || parsed?.favorites || []
      );
      const filteredChannels = channels;
      const blacklistedChannels = normalizeChannelList(parsed?.channelBlacklist || parsed?.blacklist || []);

      return {
        channels: filteredChannels,
        channelMutePrefs: buildFavoriteMutePrefs(filteredChannels, parsed?.channelMutePrefs || {}),
        blacklistedChannels
      };
    }

    const channels = normalizeChannelList(trimmed.split(/[\r\n,;]+/));
    return {
      channels,
      channelMutePrefs: {},
      blacklistedChannels: []
    };
  }

  async function exportFavoriteChannels() {
    const payload = buildFavoritesExportPayload();
    const today = new Date().toISOString().slice(0, 10);
    downloadTextFile(
      `shadowlurk-favoritos-${today}.json`,
      JSON.stringify(payload, null, 2)
    );
    setFavoritesTransferStatus('favoritesStatusExported', 'success');
  }

  async function importFavoriteChannels() {
    const file = importChannelsInput.files?.[0];
    if (!file) {
      setFavoritesTransferStatus('favoritesStatusInvalid', 'error');
      return;
    }

    try {
      const text = await file.text();
      const imported = parseImportedFavorites(text);

      if (imported.channels.length === 0) {
        setFavoritesTransferStatus('favoritesStatusEmpty', 'error');
        return;
      }

      const mergedChannels = normalizeChannelList([...currentChannels, ...imported.channels]);
      const mergedMutePrefs = buildFavoriteMutePrefs(mergedChannels, {
        ...channelMutePrefs,
        ...imported.channelMutePrefs
      });
      const mergedBlacklistedChannels = filterProtectedBlacklistChannels([
        ...blacklistedChannels,
        ...imported.blacklistedChannels
      ], mergedChannels);

      currentChannels = mergedChannels;
      channelMutePrefs = mergedMutePrefs;
      blacklistedChannels = mergedBlacklistedChannels;

      await chrome.storage.local.set({
        lurkChannels: mergedChannels,
        channelMutePrefs: mergedMutePrefs,
        channelBlacklist: mergedBlacklistedChannels
      });

      renderList(currentChannels);
      renderBlacklistList();
      renderCloseEndedLiveControls();
      setFavoritesTransferStatus('favoritesStatusImported', 'success');
    } catch (error) {
      console.error('Falha ao importar favoritos:', error);
      setFavoritesTransferStatus('favoritesStatusInvalid', 'error');
    } finally {
      importChannelsInput.value = '';
    }
  }

  async function openFixedApplication() {
    const url = new URL(APPLY_FORM_URL);
    url.searchParams.set('lang', currentLanguagePreference || 'auto');
    const targetUrl = url.toString();

    if (chrome.tabs?.create) {
      await chrome.tabs.create({ url: targetUrl });
      return;
    }

    window.open(targetUrl, '_blank', 'noopener,noreferrer');
  }

  function sanitizeAutoReloadMinutes(value) {
    const parsed = Number.parseInt(value, 10);
    if (!Number.isFinite(parsed) || parsed < 1) return 5;
    return Math.min(parsed, 720);
  }

  function updateAutoReloadControls() {
    const isEnabled = autoReloadToggle.checked;
    autoReloadMinutes.disabled = !isEnabled;
    autoReloadMinutes.closest('.auto-refresh-settings')?.classList.toggle('is-disabled', !isEnabled);
  }

  async function persistAutoReloadMinutes({ commit = false } = {}) {
    const rawValue = `${autoReloadMinutes.value ?? ''}`.trim();
    const parsed = Number.parseInt(rawValue, 10);

    if (!Number.isFinite(parsed)) {
      if (!commit) return;

      const fallbackMinutes = sanitizeAutoReloadMinutes(rawValue);
      autoReloadMinutes.value = String(fallbackMinutes);
      await chrome.storage.local.set({ autoReloadMinutes: fallbackMinutes });
      renderAutoReloadTimer().catch(() => {});
      return;
    }

    const minutes = sanitizeAutoReloadMinutes(parsed);
    if (commit) {
      autoReloadMinutes.value = String(minutes);
    }

    await chrome.storage.local.set({ autoReloadMinutes: minutes });
    renderAutoReloadTimer().catch(() => {});
  }

  async function renderTwitchApiPanel() {
    if (!twitchApiStatus || !twitchAuthBtn) return;

    const result = await chrome.storage.local.get([
      'twitchAccessToken',
      'twitchTokenExpiresAt',
      'twitchAuthLastValidatedAt',
      'twitchAuthLogin'
    ]);

    const hasToken = !!(result.twitchAccessToken || '').trim();
    const expiresAt = Number(result.twitchTokenExpiresAt) || 0;
    const lastValidatedAt = Number(result.twitchAuthLastValidatedAt) || 0;
    const login = (result.twitchAuthLogin || '').trim();
    const isExpired = expiresAt > 0 && expiresAt <= Date.now();
    const isConnected = hasToken && !isExpired;

    twitchAuthState = {
      isConnected,
      login,
      needsAttention: isConnected && (!lastValidatedAt || (Date.now() - lastValidatedAt) > 60 * 60 * 1000)
    };

    twitchApiStatus.classList.remove('is-connected', 'is-warning', 'is-error');

    if (!isConnected) {
      twitchApiStatus.textContent = localizedTexts.twitchStatusDisconnected;
      twitchApiStatus.classList.add('is-warning');
      twitchAuthBtn.textContent = localizedTexts.twitchAuthConnectButton;
      twitchAuthBtn.disabled = twitchApiBusy;
      return;
    }

    const baseStatus = login
      ? `${localizedTexts.twitchStatusConnected}: @${login}`
      : localizedTexts.twitchStatusConnected;

    twitchApiStatus.textContent = twitchAuthState.needsAttention
      ? `${baseStatus} (${localizedTexts.twitchStatusAwaitingValidation})`
      : baseStatus;
    twitchApiStatus.classList.add('is-connected');
    twitchAuthBtn.textContent = localizedTexts.twitchAuthDisconnectButton;
    twitchAuthBtn.disabled = twitchApiBusy;
  }

  async function toggleTwitchAuth() {
    if (twitchApiBusy) return;

    await renderTwitchApiPanel();
    const isConnected = twitchAuthState.isConnected === true;
    twitchApiBusy = true;
    twitchAuthBtn.disabled = true;
    twitchApiStatus.classList.remove('is-connected', 'is-warning', 'is-error');
    twitchApiStatus.classList.add('is-warning');
    twitchApiStatus.textContent = isConnected
      ? localizedTexts.twitchStatusDisconnecting
      : localizedTexts.twitchStatusConnecting;
    let actionWarning = '';

    try {
      if (isConnected) {
        const result = await chrome.runtime.sendMessage({ type: 'TWITCH_AUTH_DISCONNECT' });
        if (!result?.ok) {
          throw new Error(result?.error || 'Falha ao desconectar a Twitch.');
        }
      } else {
        const result = await chrome.runtime.sendMessage({ type: 'TWITCH_AUTH_CONNECT' });
        if (!result?.ok) {
          throw new Error(result?.error || 'Falha ao conectar a Twitch.');
        }

        if (result.warning) {
          actionWarning = result.warning;
        }
      }
    } catch (error) {
      twitchApiStatus.textContent = `${localizedTexts.twitchStatusError}: ${error?.message || error}`;
      twitchApiStatus.classList.remove('is-connected', 'is-warning');
      twitchApiStatus.classList.add('is-error');
    } finally {
      twitchApiBusy = false;
      await renderTwitchApiPanel();
      if (actionWarning) {
        twitchApiStatus.textContent = `${localizedTexts.twitchStatusWarning}: ${actionWarning}`;
        twitchApiStatus.classList.remove('is-connected', 'is-error');
        twitchApiStatus.classList.add('is-warning');
      }
    }
  }

  function startAutoReloadTimerLoop() {
    if (autoReloadTimerHandle) {
      clearInterval(autoReloadTimerHandle);
    }

    autoReloadTimerHandle = setInterval(() => {
      renderAutoReloadTimer().catch(() => {});
    }, 1000);
  }

  async function renderAutoReloadTimer() {
    if (!autoReloadTimer) return;

    const [result, alarm] = await Promise.all([
      chrome.storage.local.get(['autoReloadEnabled', 'autoReloadMinutes', 'autoReloadNextAt']),
      chrome.alarms.get(AUTO_RELOAD_ALARM)
    ]);
    const isEnabled = result.autoReloadEnabled === true;
    const intervalMinutes = sanitizeAutoReloadMinutes(result.autoReloadMinutes);

    if (!isEnabled) {
      autoReloadTimer.textContent = `${localizedTexts.autoReloadStatusLabel}: ${localizedTexts.autoReloadDisabledText}`;
      return;
    }

    const nextAt = Number(alarm?.scheduledTime || result.autoReloadNextAt) || 0;
    if (!nextAt) {
      autoReloadTimer.textContent = `${localizedTexts.autoReloadStatusLabel}: ${localizedTexts.autoReloadActiveText} (${intervalMinutes} min)`;
      return;
    }

    const remainingMs = Math.max(0, nextAt - Date.now());
    if (remainingMs <= 0) {
      autoReloadTimer.textContent = `${localizedTexts.autoReloadStatusLabel}: ${localizedTexts.autoReloadReloadingText}`;
      return;
    }

    const totalSeconds = Math.ceil(remainingMs / 1000);
    const minutes = String(Math.floor(totalSeconds / 60)).padStart(2, '0');
    const seconds = String(totalSeconds % 60).padStart(2, '0');
    autoReloadTimer.textContent = `${localizedTexts.autoReloadNextText} ${minutes}:${seconds}`;
  }

  function syncModalLock() {
    document.body.classList.toggle('modal-open', !settingsModal.hidden || !disablePrompt.hidden);
  }

  function openSettingsModal() {
    if (!settingsModal.hidden) return;
    settingsModal.hidden = false;
    syncModalLock();
    renderTwitchApiPanel().catch(() => {});
    renderCloseEndedLiveControls();
    renderAutoReloadTimer().catch(() => {});
    closeSettingsBtn.focus();
  }

  function closeSettingsModal() {
    if (settingsModal.hidden) return;
    settingsModal.hidden = true;
    syncModalLock();
    settingsBtn.focus();
  }

  function promptDisableAction() {
    if (!disablePrompt.hidden) return Promise.resolve(null);

    disablePrompt.hidden = false;
    syncModalLock();

    return new Promise((resolve) => {
      disablePromptResolver = resolve;
      keepOnlyBtn.focus();
    });
  }

  function resolveDisableAction(choice) {
    if (typeof disablePromptResolver !== 'function') return;

    disablePrompt.hidden = true;
    syncModalLock();

    const resolve = disablePromptResolver;
    disablePromptResolver = null;
    resolve(choice);
  }

  async function addChannel(channelName) {
    const result = await chrome.storage.local.get(['lurkChannels', 'channelBlacklist']);
    const channels = normalizeChannelList(result.lurkChannels || []);
    const blacklist = filterProtectedBlacklistChannels(result.channelBlacklist || []);
    const nextBlacklist = blacklist.filter((channel) => channel !== channelName);

    if (!channels.includes(channelName)) {
      channels.push(channelName);
      currentChannels = channels;
      channelMutePrefs = buildFavoriteMutePrefs(channels, channelMutePrefs);
      blacklistedChannels = nextBlacklist;
      await chrome.storage.local.set({
        lurkChannels: channels,
        channelMutePrefs,
        channelBlacklist: nextBlacklist
      });
      if (nextBlacklist.length !== blacklist.length) {
        setBlacklistStatus('blacklistStatusRemoved', 'info');
      }
      renderList(channels);
      renderBlacklistList();
      renderCloseEndedLiveControls();
    }
  }

  async function removeChannel(channelName) {
    const result = await chrome.storage.local.get(['lurkChannels']);
    const channels = normalizeChannelList(result.lurkChannels || []).filter((channel) => channel !== channelName);
    currentChannels = channels;
    channelMutePrefs = buildFavoriteMutePrefs(channels, channelMutePrefs);
    const nextMutePrefs = { ...channelMutePrefs };
    delete nextMutePrefs[channelName];
    channelMutePrefs = nextMutePrefs;
    await chrome.storage.local.set({
      lurkChannels: channels,
      channelMutePrefs: nextMutePrefs
    });
    try {
      await chrome.runtime.sendMessage({ type: 'PURGE_CHANNEL', channel: channelName });
    } catch {}
    renderList(channels);
    renderCloseEndedLiveControls();
  }

  async function addBlacklistChannel(channelName) {
    try {
      const normalized = normalizeChannel(channelName);
      if (!normalized) {
        setBlacklistStatus('blacklistStatusInvalid', 'error');
        return false;
      }

      const protectionReason = getBlacklistProtectionReason(normalized);
      if (protectionReason === 'favorite') {
        setBlacklistStatus('blacklistStatusFavoriteBlocked', 'error');
        return false;
      }

      if (protectionReason === 'fixed') {
        setBlacklistStatus('blacklistStatusFixedBlocked', 'error');
        return false;
      }

      const result = await chrome.storage.local.get(['channelBlacklist']);
      const channels = filterProtectedBlacklistChannels(result.channelBlacklist || []);

      if (!channels.includes(normalized)) {
        channels.push(normalized);
        blacklistedChannels = channels;
        await chrome.storage.local.set({ channelBlacklist: channels });
        try {
          await chrome.runtime.sendMessage({ type: 'ENFORCE_BLACKLIST' });
        } catch {}
        setBlacklistStatus('blacklistStatusAdded', 'success');
        renderBlacklistList();
        return true;
      }

      setBlacklistStatus('blacklistStatusAlreadyAdded', 'info');
      return false;
    } catch (error) {
      console.warn('Falha ao adicionar canal na blacklist:', error);
      setBlacklistStatus('blacklistStatusSaveError', 'error');
      return false;
    }
  }

  async function removeBlacklistChannel(channelName) {
    const result = await chrome.storage.local.get(['channelBlacklist']);
    const channels = filterProtectedBlacklistChannels(result.channelBlacklist || []).filter((channel) => channel !== channelName);
    blacklistedChannels = channels;
    await chrome.storage.local.set({ channelBlacklist: channels });
    setBlacklistStatus('blacklistStatusRemoved', 'info');
    renderBlacklistList();
  }

  async function setMutePref(channelName, isMuted) {
    const key = channelName.toLowerCase();
    channelMutePrefs[key] = !!isMuted;
    await chrome.storage.local.set({ channelMutePrefs });
  }

  function createMuteControl(channel) {
    const controls = document.createElement('div');
    controls.className = 'control-group';

    const labelText = document.createElement('span');
    labelText.textContent = localizedTexts.muteLabel;
    labelText.className = 'control-label';

    const toggleLabel = document.createElement('label');
    toggleLabel.className = 'switch';

    const toggle = document.createElement('input');
    const slider = document.createElement('span');

    toggle.type = 'checkbox';
    toggle.checked = channelMutePrefs[channel.toLowerCase()] !== false;
    toggle.addEventListener('change', () => {
      setMutePref(channel, toggle.checked);
    });

    slider.className = 'slider round';
    toggleLabel.appendChild(toggle);
    toggleLabel.appendChild(slider);

    controls.appendChild(labelText);
    controls.appendChild(toggleLabel);
    return controls;
  }

  function renderList(channels) {
    channelList.innerHTML = '';

    channels.forEach((channel) => {
      const li = document.createElement('li');

      const name = document.createElement('span');
      name.textContent = channel;
      name.className = 'channel-name';

      const controls = createMuteControl(channel);

      const removeBtn = document.createElement('button');
      removeBtn.type = 'button';
      removeBtn.innerHTML = '&times;';
      removeBtn.className = 'remove-btn';
      removeBtn.title = localizedTexts.removeChannel;
      removeBtn.setAttribute('aria-label', localizedTexts.removeChannel);
      removeBtn.onclick = () => removeChannel(channel);

      li.appendChild(name);
      li.appendChild(controls);
      li.appendChild(removeBtn);
      channelList.appendChild(li);
    });
  }

  function renderPartnerList() {
    partnerList.innerHTML = '';

    PARTNER_CHANNELS.forEach((channel) => {
      const li = document.createElement('li');

      const name = document.createElement('span');
      name.textContent = channel;
      name.className = 'channel-name';

      const controls = createMuteControl(channel);

      li.appendChild(name);
      li.appendChild(controls);
      partnerList.appendChild(li);
    });
  }

  function renderBlacklistList() {
    if (!blacklistList) return;

    blacklistList.innerHTML = '';

    if (blacklistedChannels.length === 0) {
      const li = document.createElement('li');
      li.className = 'blacklist-empty-item';
      li.textContent = localizedTexts.blacklistEmptyText || '';
      blacklistList.appendChild(li);
      return;
    }

    blacklistedChannels.forEach((channel) => {
      const li = document.createElement('li');

      const name = document.createElement('span');
      name.textContent = channel;
      name.className = 'channel-name';

      const removeBtn = document.createElement('button');
      removeBtn.type = 'button';
      removeBtn.innerHTML = '&times;';
      removeBtn.className = 'remove-btn';
      removeBtn.title = localizedTexts.removeChannel;
      removeBtn.setAttribute('aria-label', localizedTexts.removeChannel);
      removeBtn.onclick = () => removeBlacklistChannel(channel);

      li.appendChild(name);
      li.appendChild(removeBtn);
      blacklistList.appendChild(li);
    });
  }
});
