document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('fixedForm');
  const languageSelect = document.getElementById('languageSelect');
  const discordHandle = document.getElementById('discordHandle');
  const realName = document.getElementById('realName');
  const twitchNick = document.getElementById('twitchNick');
  const email = document.getElementById('email');
  const termsConsent = document.getElementById('termsConsent');
  const previewMessage = document.getElementById('previewMessage');
  const botMessageText = document.getElementById('botMessageText');
  const subjectField = document.getElementById('subjectField');
  const formStatus = document.getElementById('formStatus');
  const submitButton = form.querySelector('button[type="submit"]');

  const LANGUAGE_OPTIONS = [
    { value: 'auto', label: 'Auto' },
    { value: 'pt-BR', label: 'Português (Brasil)' },
    { value: 'en', label: 'English' },
    { value: 'es', label: 'Español' },
    { value: 'fr', label: 'Français' },
    { value: 'de', label: 'Deutsch' },
    { value: 'it', label: 'Italiano' },
    { value: 'ja', label: '日本語' },
    { value: 'ko', label: '한국어' },
    { value: 'ru', label: 'Русский' },
    { value: 'zh-CN', label: '中文（简体）' },
    { value: 'zh-TW', label: '中文（繁體）' },
    { value: 'ar', label: 'العربية' },
    { value: 'hi', label: 'हिन्दी' },
    { value: 'tr', label: 'Türkçe' },
    { value: 'nl', label: 'Nederlands' },
    { value: 'pl', label: 'Polski' },
    { value: 'id', label: 'Bahasa Indonesia' },
    { value: 'vi', label: 'Tiếng Việt' },
    { value: 'pt-PT', label: 'Português (Portugal)' }
  ];

  const RTL_LANGUAGES = new Set(['ar', 'fa', 'he', 'ur']);
  const formspreeEndpoint = 'https://formspree.io/f/xojbbvgq';
  const translationCache = new Map();
  let localizationToken = 0;
  let currentLanguagePreference = 'auto';
  let currentResolvedLanguage = 'pt-BR';
  let localizedTexts = {};

  const BASE_TEXTS = {
    pageTitle: 'ShadowLurk | Pedido de Fixo',
    brand: 'ShadowLurk',
    heroTitle: 'Pedido para virar canal fixo',
    heroLead: 'Preencha o formulário abaixo para solicitar sua inclusão na lista fixa da extensão. Eu recebo os dados pelo Formspree e respondo por e-mail quando a análise for concluída.',
    languageLabel: 'Idioma do site',
    languageHint: 'Escolha o idioma da página. Se deixar automático, ela segue sua preferência salva ou o idioma do navegador.',
    languageAutoOption: 'Automático',
    previewTitle: 'Mensagem sugerida para o bot',
    discordLabel: 'Nick do Discord *',
    realNameLabel: 'Nome completo',
    twitchLabel: 'Nick da Twitch *',
    emailLabel: 'E-mail *',
    discordPlaceholder: '@seuNick',
    realNamePlaceholder: 'Opcional',
    twitchPlaceholder: 'seuCanal',
    emailPlaceholder: 'voce@exemplo.com',
    termsTitle: 'Termos para participar',
    termsGreeting: 'Opa! Tudo bem?',
    termsIntro: 'Eu sou o Felipenor e vim te dar uma notícia top! 🚀',
    termsBenefit: 'Adicionei seu canal como FIXO na minha extensão ShadowLurk. Isso significa que todos os usuários com a extensão instalada vão abrir automaticamente a sua live em lurk (aba mutada em segundo plano) assim que você iniciar a transmissão. Mais views e mais lurkers pra você de graça. 😎',
    termsRequest: 'A única coisa que peço em troca para manter seu canal fixo na lista é uma ajuda na divulgação. Configure o StreamElements (ou o bot de chat que você usa) para enviar periodicamente o link da extensão no chat.',
    botMessageLabel: 'Mensagem sugerida para o bot',
    termsClosing: 'Se puder dar essa força, seu canal continua fixo na extensão e a gente cresce junto! Caso contrário, precisarei remover o fixo na próxima atualização, beleza?',
    termsFarewell: 'Tmj e boas lives! 💜',
    betaNote: 'Se notar qualquer erro na extensão, como falha para abrir sua live ou a de algum canal favorito, me avise. A ShadowLurk ainda está em fase beta.',
    consentText: 'Concordo com os termos acima e autorizo o envio da minha inscrição.',
    submitButton: 'Enviar inscrição',
    statusConsentRequired: 'Você precisa concordar com os termos para enviar o formulário.',
    statusFillRequired: 'Revise os campos obrigatórios antes de enviar.',
    statusSending: 'Enviando inscrição...',
    statusSuccess: 'Inscrição enviada com sucesso. Vou analisar e responder por e-mail.',
    statusFailure: 'Não consegui enviar agora. Tente novamente em alguns minutos.',
    subjectTemplate: 'ShadowLurk - pedido de fixo',
    botMessageTemplate: 'Galera, baixem a extensão ShadowLurk! Ela ajuda a farmar pontos, baixar emotes e dá aquele lurk maroto pra fortalecer a live! Seja do canal do [[NICK]] ou dos seus canais favoritos. Baixe aqui: https://felipenor.github.io/ShadowLurk',
    defaultNickFallback: 'seuCanal'
  };

  bindEvents();
  initialize().catch((error) => {
    console.error('Erro ao inicializar a página de inscrição:', error);
  });

  function bindEvents() {
    languageSelect.addEventListener('change', async () => {
      await setLanguagePreference(languageSelect.value, { persist: true });
    });

    twitchNick.addEventListener('input', updatePreview);
    discordHandle.addEventListener('input', () => {
      if (discordHandle.value && !discordHandle.value.startsWith('@')) {
        discordHandle.value = `@${discordHandle.value.replace(/^@+/, '')}`;
      }
    });

    [realName, discordHandle, twitchNick, email].forEach((field) => {
      field.addEventListener('input', () => {
        formStatus.textContent = '';
      });
    });

    form.addEventListener('submit', handleSubmit);
  }

  async function initialize() {
    const params = new URLSearchParams(window.location.search);
    const queryLanguage = normalizeLanguagePreference(params.get('lang'));
    const stored = await chrome.storage.local.get(['uiLanguage']);
    const initialPreference = queryLanguage || normalizeLanguagePreference(stored.uiLanguage) || 'auto';

    await setLanguagePreference(initialPreference, { persist: false });
  }

  function normalizeLanguagePreference(value) {
    if (!value) return null;
    const normalized = normalizeLanguageCode(value);
    return normalized || null;
  }

  function normalizeLanguageCode(value) {
    const raw = String(value || '').trim();
    if (!raw) return null;
    const lower = raw.toLowerCase();
    if (lower === 'auto') return 'auto';
    if (lower.startsWith('pt')) return lower.includes('pt-pt') ? 'pt-PT' : 'pt-BR';
    if (lower.startsWith('zh')) {
      if (lower.includes('tw') || lower.includes('hk')) return 'zh-TW';
      return 'zh-CN';
    }
    return lower.split('-')[0] || null;
  }

  function getBrowserLanguage() {
    return normalizeLanguageCode(chrome.i18n?.getUILanguage?.() || navigator.language || 'pt-BR') || 'pt-BR';
  }

  function resolveEffectiveLanguage(preference) {
    if (!preference || preference === 'auto') {
      return getBrowserLanguage();
    }
    return normalizeLanguageCode(preference) || 'en';
  }

  async function setLanguagePreference(preference, options = {}) {
    const { persist = true } = options;
    currentLanguagePreference = normalizeLanguagePreference(preference) || 'auto';
    currentResolvedLanguage = resolveEffectiveLanguage(currentLanguagePreference);
    const token = ++localizationToken;

    localizedTexts = await buildLocalizedTexts(currentResolvedLanguage);
    if (token !== localizationToken) return;

    applyLocalizedTexts();
    renderLanguageOptions();
    renderPreview();

    if (persist) {
      await chrome.storage.local.set({ uiLanguage: currentLanguagePreference });
    }
  }

  async function buildLocalizedTexts(targetLanguage) {
    if (targetLanguage.startsWith('pt')) {
      return { ...BASE_TEXTS };
    }

    const entries = await Promise.all(
      Object.entries(BASE_TEXTS).map(async ([key, text]) => [key, await translateText(text, targetLanguage)])
    );

    return Object.fromEntries(entries);
  }

  async function translateText(text, targetLanguage) {
    if (!text) return text;
    if (targetLanguage.startsWith('pt')) return text;

    const cacheKey = `${targetLanguage}::${text}`;
    if (translationCache.has(cacheKey)) {
      return translationCache.get(cacheKey);
    }

    try {
      const url = new URL('https://translate.googleapis.com/translate_a/single');
      url.searchParams.set('client', 'gtx');
      url.searchParams.set('sl', 'pt');
      url.searchParams.set('tl', targetLanguage);
      url.searchParams.set('dt', 't');
      url.searchParams.set('q', text);

      const response = await fetch(url.toString(), { cache: 'no-store' });
      if (!response.ok) throw new Error(`Translate HTTP ${response.status}`);

      const data = await response.json();
      const translated = Array.isArray(data?.[0])
        ? data[0].map((segment) => segment?.[0] || '').join('')
        : text;
      const finalText = translated || text;
      translationCache.set(cacheKey, finalText);
      return finalText;
    } catch (error) {
      console.warn('Falha ao traduzir a página de inscrição:', error);
      translationCache.set(cacheKey, text);
      return text;
    }
  }

  function applyLocalizedTexts() {
    document.documentElement.lang = currentResolvedLanguage;
    const direction = RTL_LANGUAGES.has(currentResolvedLanguage) ? 'rtl' : 'ltr';
    document.documentElement.dir = direction;
    document.body.dir = direction;
    document.title = localizedTexts.pageTitle || BASE_TEXTS.pageTitle;

    document.querySelectorAll('[data-i18n]').forEach((element) => {
      const key = element.dataset.i18n;
      if (localizedTexts[key]) {
        element.textContent = localizedTexts[key];
      }
    });

    discordHandle.setAttribute('placeholder', localizedTexts.discordPlaceholder || BASE_TEXTS.discordPlaceholder);
    realName.setAttribute('placeholder', localizedTexts.realNamePlaceholder || BASE_TEXTS.realNamePlaceholder);
    twitchNick.setAttribute('placeholder', localizedTexts.twitchPlaceholder || BASE_TEXTS.twitchPlaceholder);
    email.setAttribute('placeholder', localizedTexts.emailPlaceholder || BASE_TEXTS.emailPlaceholder);
    languageSelect.setAttribute('aria-label', localizedTexts.languageLabel || BASE_TEXTS.languageLabel);
    subjectField.value = localizedTexts.subjectTemplate || BASE_TEXTS.subjectTemplate;
  }

  function renderLanguageOptions() {
    languageSelect.innerHTML = '';

    for (const optionDef of LANGUAGE_OPTIONS) {
      const option = document.createElement('option');
      option.value = optionDef.value;
      option.textContent = optionDef.value === 'auto' ? (localizedTexts.languageAutoOption || BASE_TEXTS.languageAutoOption) : optionDef.label;
      languageSelect.appendChild(option);
    }

    languageSelect.value = currentLanguagePreference;
  }

  function getDisplayNick() {
    const nick = twitchNick.value.trim();
    return nick || (localizedTexts.defaultNickFallback || BASE_TEXTS.defaultNickFallback);
  }

  function renderPreview() {
    const nick = getDisplayNick();
    const template = localizedTexts.botMessageTemplate || BASE_TEXTS.botMessageTemplate;
    const message = template.replace('[[NICK]]', nick);

    previewMessage.textContent = message;
    botMessageText.textContent = message;
    subjectField.value = `${localizedTexts.subjectTemplate || BASE_TEXTS.subjectTemplate} (${nick})`;
  }

  function updatePreview() {
    renderPreview();
  }

  async function handleSubmit(event) {
    event.preventDefault();

    if (!termsConsent.checked) {
      formStatus.textContent = localizedTexts.statusConsentRequired || BASE_TEXTS.statusConsentRequired;
      formStatus.style.color = '#ffb347';
      termsConsent.focus();
      return;
    }

    if (!form.reportValidity()) {
      formStatus.textContent = localizedTexts.statusFillRequired || BASE_TEXTS.statusFillRequired;
      formStatus.style.color = '#ffb347';
      return;
    }

    submitButton.disabled = true;
    formStatus.textContent = localizedTexts.statusSending || BASE_TEXTS.statusSending;
    formStatus.style.color = '#b0b0bf';

    const payload = new FormData(form);
    payload.set('bot_message', botMessageText.textContent || '');
    payload.set('terms_text', localizedTexts.consentText || BASE_TEXTS.consentText);
    payload.set('_subject', subjectField.value);

    try {
      const response = await fetch(formspreeEndpoint, {
        method: 'POST',
        headers: {
          Accept: 'application/json'
        },
        body: payload
      });

      if (!response.ok) {
        throw new Error(`Formspree respondeu com status ${response.status}`);
      }

      formStatus.textContent = localizedTexts.statusSuccess || BASE_TEXTS.statusSuccess;
      formStatus.style.color = '#00db84';
      form.reset();
      termsConsent.checked = false;
      updatePreview();
    } catch (error) {
      console.error('Falha ao enviar o formulário:', error);
      formStatus.textContent = localizedTexts.statusFailure || BASE_TEXTS.statusFailure;
      formStatus.style.color = '#ff6b6b';
    } finally {
      submitButton.disabled = false;
    }
  }
});
