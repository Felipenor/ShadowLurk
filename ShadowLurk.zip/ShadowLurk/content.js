let extensionEnabled = true;

chrome.storage.local.get(['extensionEnabled'], (res) => {
  extensionEnabled = res.extensionEnabled !== false;
  if (extensionEnabled) {
    initShadowLurk();
  }
});

function initShadowLurk() {
  console.log('ShadowLurk iniciado');
  setLowQuality();
  checkAdBlock();
  startPointClaimer();
  initEmoteDownloader();
  initVideoLooper();
  initRaidWatcher();
  initMessageBridge();
  requestBlacklistSweep();
}

function initVideoLooper() {
  if (!window.location.href.includes('videos/2367175351')) return;

  const tryAutoplayAfterReload = () => {
    const video = document.querySelector('video');
    if (!video) return;

    chrome.storage.local.get(['channelMutePrefs'], (res) => {
      try {
        const prefs = res.channelMutePrefs || {};
        const muted = prefs['felipenor'] !== false;
        video.muted = muted;
        const playResult = video.play();
        if (playResult && typeof playResult.then === 'function') {
          playResult.catch(() => {});
        }
      } catch {}
    });
  };

  window.addEventListener('load', () => {
    const flag = sessionStorage.getItem('shadowlurk_vod_reload');
    if (flag === '1') {
      sessionStorage.removeItem('shadowlurk_vod_reload');
      tryAutoplayAfterReload();
    }
  });

  setInterval(() => {
    const video = document.querySelector('video');
    if (video && video.ended) {
      try {
        sessionStorage.setItem('shadowlurk_vod_reload', '1');
      } catch {}
      window.location.reload();
    }
  }, 1000);
}

function setLowQuality() {
  try {
    localStorage.setItem('video-quality', '{"default":"160p30"}');
  } catch (error) {
    console.log('Erro ao definir qualidade:', error);
  }
}

function checkAdBlock() {
  const bait = document.createElement('div');
  bait.className = 'ad-banner adsbox doubleclick';
  bait.style.position = 'absolute';
  bait.style.top = '-999px';
  bait.style.left = '-999px';
  bait.style.width = '1px';
  bait.style.height = '1px';
  document.body.appendChild(bait);

  setTimeout(() => {
    const isBlocked = bait.offsetHeight === 0 || window.getComputedStyle(bait).display === 'none';
    bait.remove();

    if (isBlocked) {
      showAdBlockOverlay();
    }
  }, 1000);
}

function showAdBlockOverlay() {
  if (document.getElementById('shadowlurk-adblock-overlay')) return;

  const overlay = document.createElement('div');
  overlay.id = 'shadowlurk-adblock-overlay';
  overlay.innerHTML = `
    <h1>ShadowLurk detectou um bloqueador de anúncios</h1>
    <p>Para apoiar o criador (Felipenor) e usar esta extensão, por favor desative seu AdBlock neste site.</p>
    <p>Recarregue a página após desativar.</p>
    <button type="button" onclick="location.reload()" style="padding: 10px 20px; background: #9146FF; border: none; color: white; border-radius: 4px; cursor: pointer; font-weight: bold;">Já desativei (recarregar)</button>
  `;
  document.body.appendChild(overlay);
  document.body.style.overflow = 'hidden';
}

function startPointClaimer() {
  setInterval(() => {
    const bonusButton = document.querySelector('[aria-label="Resgatar Bônus"]');
    if (bonusButton) {
      console.log('ShadowLurk: bônus coletado!');
      bonusButton.click();
    }

    const chestIcon = document.querySelector('.claimable-bonus__icon');
    if (chestIcon) {
      chestIcon.click();
    }
  }, 10000);
}

function initEmoteDownloader() {
  const observer = new MutationObserver((mutations) => {
    for (const mutation of mutations) {
      if (mutation.addedNodes.length) {
        const emotePicker = document.querySelector('[data-test-selector="emote-picker"]');
        if (emotePicker && !emotePicker.dataset.shadowlurkInit) {
          setupEmotePicker(emotePicker);
        }
      }
    }
  });

  observer.observe(document.body, { childList: true, subtree: true });

  document.addEventListener('click', (event) => {
    if (event.altKey && event.target.tagName === 'IMG' && event.target.classList.contains('chat-line__message--emote')) {
      event.preventDefault();
      event.stopPropagation();
      downloadEmote(event.target.src, event.target.alt);
    }
  }, true);
}

function setupEmotePicker(picker) {
  picker.dataset.shadowlurkInit = 'true';

  const header = picker.querySelector('.emote-picker__header') || picker.firstChild;
  if (header) {
    const info = document.createElement('div');
    info.style.padding = '5px';
    info.style.fontSize = '11px';
    info.style.color = '#9146FF';
    info.style.textAlign = 'center';
    info.innerText = 'ShadowLurk: Segure ALT e clique em um emote para baixar.';
    header.insertBefore(info, header.firstChild);
  }

  picker.addEventListener('click', (event) => {
    if (event.altKey && event.target.tagName === 'IMG') {
      event.preventDefault();
      event.stopPropagation();

      let src = event.target.src;
      if (src.includes('/1.0')) src = src.replace('/1.0', '/3.0');
      else if (src.includes('/2.0')) src = src.replace('/2.0', '/3.0');

      const name = event.target.alt || 'emote';
      downloadEmote(src, name);
    }
  }, true);
}

function downloadEmote(url, name) {
  fetch(url)
    .then((response) => response.blob())
    .then((blob) => {
      const blobUrl = window.URL.createObjectURL(blob);
      const anchor = document.createElement('a');
      anchor.style.display = 'none';
      anchor.href = blobUrl;
      const safeName = (name || 'emote').replace(/[^a-z0-9]/gi, '_') || 'emote';
      anchor.download = `${safeName}.png`;
      document.body.appendChild(anchor);
      anchor.click();
      window.URL.revokeObjectURL(blobUrl);

      showToast(`Emote ${name} baixado!`);
    })
    .catch((error) => console.error('Erro ao baixar emote:', error));
}

function showToast(message) {
  const toast = document.createElement('div');
  toast.className = 'shadowlurk-toast';
  toast.innerText = message;
  document.body.appendChild(toast);
  setTimeout(() => {
    toast.remove();
  }, 3000);
}

function normalizeChannelName(channel) {
  return (channel || '').toLowerCase();
}

function normalizeChannelList(channels) {
  return [...new Set((channels || []).map((channel) => normalizeChannelName(channel)).filter(Boolean))];
}

function isBlacklistedRaidTarget(channelName) {
  return new Promise((resolve) => {
    chrome.storage.local.get(['channelBlacklist'], (res) => {
      const blacklist = new Set(normalizeChannelList(res.channelBlacklist || []));
      resolve(blacklist.has(normalizeChannelName(channelName)));
    });
  });
}

function requestBlacklistSweep() {
  try {
    chrome.runtime.sendMessage({ type: 'ENFORCE_BLACKLIST' });
  } catch {}
}

async function handleRaidTarget(fromChannel, toChannel) {
  if (await isBlacklistedRaidTarget(toChannel)) {
    try {
      chrome.runtime.sendMessage({ type: 'RAID_PROMPT_ACTION', action: 'close', toChannel });
    } catch {}
    return;
  }

  try {
    chrome.runtime.sendMessage({ type: 'RAID_DETECTED' });
  } catch {}

  showRaidPrompt(fromChannel, toChannel);
}

function initRaidWatcher() {
  const isVod = window.location.pathname.startsWith('/videos/');
  if (isVod) return;

  let lastPath = window.location.pathname;
  let lastChannel = getChannelFromPath(lastPath);
  let lastPromptSignature = '';
  let lastPromptAt = 0;

  const attachEndedListener = () => {
    const video = document.querySelector('video');
    if (!video || video.dataset.shadowlurkRaidBound === '1') return;

    video.dataset.shadowlurkRaidBound = '1';
    video.addEventListener('ended', () => {
      chrome.runtime.sendMessage({ type: 'LIVE_ENDED' });
    });
  };

  const emitRaidPrompt = (fromChannel, toChannel) => {
    const signature = `${fromChannel}->${toChannel}`;
    const now = Date.now();
    if (lastPromptSignature === signature && (now - lastPromptAt) < 10000) return;

    lastPromptSignature = signature;
    lastPromptAt = now;

    handleRaidTarget(fromChannel, toChannel).catch(() => {});
  };

  const handleNavigationChange = () => {
    const currentPath = window.location.pathname;
    if (currentPath === lastPath) return;

    const previousChannel = lastChannel;
    const nextChannel = getChannelFromPath(currentPath);
    lastPath = currentPath;
    lastChannel = nextChannel;

    if (nextChannel) {
      requestBlacklistSweep();
    }

    if (!previousChannel || !nextChannel || previousChannel === nextChannel) return;
    if (currentPath.startsWith('/videos/')) return;

    emitRaidPrompt(previousChannel, nextChannel);
  };

  if (!window.__shadowlurkRaidHistoryPatched) {
    window.__shadowlurkRaidHistoryPatched = true;

    const wrapHistoryMethod = (methodName) => {
      const original = history[methodName];
      if (typeof original !== 'function') return;

      history[methodName] = function (...args) {
        const result = original.apply(this, args);
        queueMicrotask(handleNavigationChange);
        return result;
      };
    };

    wrapHistoryMethod('pushState');
    wrapHistoryMethod('replaceState');
    window.addEventListener('popstate', handleNavigationChange);
    window.addEventListener('hashchange', handleNavigationChange);
  }

  attachEndedListener();

  const observer = new MutationObserver(() => {
    attachEndedListener();
  });

  observer.observe(document.documentElement, { childList: true, subtree: true });
  setInterval(handleNavigationChange, 1000);
}

function getChannelFromPath(pathname) {
  const parts = String(pathname || '').split('/').filter(Boolean);
  const first = parts[0];
  if (!first || first === 'videos') return null;
  return first.toLowerCase();
}

function initMessageBridge() {
  chrome.runtime.onMessage.addListener((msg) => {
    if (msg.type === 'SHOW_RAID_PROMPT') {
      handleRaidTarget(msg.fromChannel, msg.toChannel).catch(() => {});
      return;
    }

    if (msg.type === 'SHOW_BLACKLIST_NOTICE') {
      showBlacklistNotice(msg.channel || msg.channelName || 'desconhecido');
    }
  });
}

const BLACKLIST_NOTICE_OVERLAY_ID = 'shadowlurk-blacklist-overlay';

function showBlacklistNotice(channelName) {
  const normalizedChannel = (channelName || '').trim() || 'desconhecido';
  const existing = document.getElementById(BLACKLIST_NOTICE_OVERLAY_ID);

  if (existing) {
    const channelLabel = existing.querySelector('.shadowlurk-blacklist-channel');
    const okButton = existing.querySelector('.shadowlurk-blacklist-ok');
    if (channelLabel) channelLabel.textContent = normalizedChannel;
    if (okButton) okButton.focus();
    return;
  }

  if (!document.body) return;

  const previousHtmlOverflow = document.documentElement.style.overflow;
  const previousBodyOverflow = document.body.style.overflow;

  const overlay = document.createElement('div');
  overlay.id = BLACKLIST_NOTICE_OVERLAY_ID;
  overlay.innerHTML = `
    <div class="shadowlurk-blacklist-card" role="dialog" aria-modal="true" aria-labelledby="shadowlurk-blacklist-title">
      <p class="shadowlurk-blacklist-eyebrow">SHADOWLURK</p>
      <h1 id="shadowlurk-blacklist-title">Guia fechada por blacklist</h1>
      <p class="shadowlurk-blacklist-message">
        A guia do canal <strong class="shadowlurk-blacklist-channel"></strong> foi fechada porque esse canal está na blacklist.
        Clique em <strong>OK</strong> para fechar este aviso.
      </p>
      <div class="shadowlurk-blacklist-actions">
        <button type="button" class="shadowlurk-blacklist-ok">OK</button>
      </div>
    </div>
  `;

  const channelLabel = overlay.querySelector('.shadowlurk-blacklist-channel');
  const okButton = overlay.querySelector('.shadowlurk-blacklist-ok');

  if (channelLabel) {
    channelLabel.textContent = normalizedChannel;
  }

  const closeNotice = () => {
    overlay.remove();
    document.documentElement.style.overflow = previousHtmlOverflow;
    document.body.style.overflow = previousBodyOverflow;
    document.removeEventListener('keydown', handleKeyDown, true);
  };

  const handleKeyDown = (event) => {
    if (event.key === 'Escape' || event.key === 'Enter') {
      event.preventDefault();
      closeNotice();
    }
  };

  overlay.addEventListener('click', (event) => {
    if (event.target === overlay) {
      closeNotice();
    }
  });

  okButton?.addEventListener('click', closeNotice);
  document.addEventListener('keydown', handleKeyDown, true);
  document.documentElement.style.overflow = 'hidden';
  document.body.style.overflow = 'hidden';
  document.body.appendChild(overlay);
  okButton?.focus();
}

function showRaidPrompt(fromChannel, toChannel) {
  if (document.querySelector('.shadowlurk-raid-popup')) return;

  const popup = document.createElement('div');
  popup.className = 'shadowlurk-raid-popup';
  popup.innerHTML = `
    <div class="shadowlurk-raid-header">
      <div>
        <h3>ShadowLurk: Raid detectada</h3>
        <p>O canal <strong>${fromChannel}</strong> encerrou a live e raidou <strong>${toChannel}</strong>.</p>
      </div>
      <button type="button" class="shadowlurk-raid-close" aria-label="Fechar aviso">&times;</button>
    </div>
    <p>Clique no X para continuar assistindo. Se quiser encerrar esta guia, use o botão vermelho abaixo.</p>
    <div class="shadowlurk-raid-actions">
      <button type="button" class="shadowlurk-btn close-guide">Fechar guia</button>
    </div>
  `;

  const dismissBtn = popup.querySelector('.shadowlurk-raid-close');
  const closeBtn = popup.querySelector('.close-guide');

  const dismissPopup = () => {
    chrome.runtime.sendMessage({ type: 'RAID_PROMPT_ACTION', action: 'keep', toChannel });
    popup.remove();
  };

  const closeGuide = () => {
    chrome.runtime.sendMessage({ type: 'RAID_PROMPT_ACTION', action: 'close' });
    popup.remove();
  };

  dismissBtn.addEventListener('click', dismissPopup);
  closeBtn.addEventListener('click', closeGuide);

  const root = document.body || document.documentElement;
  if (!root) return;

  document.documentElement.style.overflow = 'hidden';
  if (document.body) {
    document.body.style.overflow = 'hidden';
  }
  root.appendChild(popup);
  closeBtn?.focus();
}
